// Exercicio 17.6 - Rational.cpp
#include <iostream>
#include <cstdlib>
#include "Rational.h"
using namespace std;

Rational::Rational(int numerador, int denominador)
    : num(numerador), den(denominador) {
    if (den == 0) {
        cout << "Erro: denominador 0. Ajustado para 1." << endl;
        den = 1;
    }
    // Sinal negativo sempre no numerador
    if (den < 0) { num = -num; den = -den; }
    reduzir();
}

int Rational::mdc(int a, int b) {
    a = abs(a); b = abs(b);
    while (b != 0) { int t = b; b = a % b; a = t; }
    return a == 0 ? 1 : a;
}

void Rational::reduzir() {
    int d = mdc(num, den);
    num /= d;
    den /= d;
}

Rational Rational::add(const Rational &o) const {
    return Rational(num * o.den + o.num * den, den * o.den);
}

Rational Rational::subtract(const Rational &o) const {
    return Rational(num * o.den - o.num * den, den * o.den);
}

Rational Rational::multiply(const Rational &o) const {
    return Rational(num * o.num, den * o.den);
}

Rational Rational::divide(const Rational &o) const {
    return Rational(num * o.den, den * o.num);
}

void Rational::printFraction() const {
    cout << num << "/" << den;
}

void Rational::printFloatingPoint() const {
    cout << static_cast<double>(num) / den;
}
