// Exercicio 17.6 - Rational.h
// Classe Rational para aritmetica com fracoes, sempre em forma reduzida
#ifndef RATIONAL_H
#define RATIONAL_H

class Rational {
public:
    // Construtor com valores default (numerador=0, denominador=1)
    Rational(int numerador = 0, int denominador = 1);

    Rational add(const Rational &o) const;
    Rational subtract(const Rational &o) const;
    Rational multiply(const Rational &o) const;
    Rational divide(const Rational &o) const;

    void printFraction() const;        // a/b
    void printFloatingPoint() const;   // a/b como double

private:
    int num;     // numerador
    int den;     // denominador (sempre > 0)

    void reduzir();                    // simplifica num/den
    static int mdc(int a, int b);      // maior divisor comum
};

#endif
