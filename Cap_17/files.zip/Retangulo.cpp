// Exercicio 17.11 - Retangulo.cpp
#include <iostream>
#include "Retangulo.h"
using namespace std;

Retangulo::Retangulo(double comp, double larg) {
    setComprimento(comp);
    setLargura(larg);
}

void Retangulo::setComprimento(double c) {
    if (c > 0.0 && c < 20.0) {
        comprimento = c;
    } else {
        cout << "Comprimento invalido (" << c
             << "). Definido como 1.0." << endl;
        comprimento = 1.0;
    }
}

void Retangulo::setLargura(double l) {
    if (l > 0.0 && l < 20.0) {
        largura = l;
    } else {
        cout << "Largura invalida (" << l
             << "). Definida como 1.0." << endl;
        largura = 1.0;
    }
}

double Retangulo::getComprimento() const { return comprimento; }
double Retangulo::getLargura()    const { return largura;     }

double Retangulo::perimetro() const {
    return 2.0 * (comprimento + largura);
}

double Retangulo::area() const {
    return comprimento * largura;
}
