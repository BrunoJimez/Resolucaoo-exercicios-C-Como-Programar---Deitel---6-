// Exercicio 17.11 - Retangulo.h
// Retangulo simples com comprimento e largura, defaults = 1
#ifndef RETANGULO_H
#define RETANGULO_H

class Retangulo {
public:
    Retangulo(double comp = 1.0, double larg = 1.0);

    // Setters validam: > 0.0 e < 20.0
    void setComprimento(double c);
    void setLargura(double l);
    double getComprimento() const;
    double getLargura() const;

    double perimetro() const;
    double area() const;

private:
    double comprimento;
    double largura;
};

#endif
