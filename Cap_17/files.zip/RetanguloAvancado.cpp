// Exercicio 17.12 - RetanguloAvancado.cpp
#include <iostream>
#include <cmath>
#include "RetanguloAvancado.h"
using namespace std;

RetanguloAvancado::RetanguloAvancado(double a, double b, double c, double d,
                                     double e, double f, double g, double h) {
    set(a, b, c, d, e, f, g, h);
}

void RetanguloAvancado::set(double a, double b, double c, double d,
                            double e, double f, double g, double h) {
    // Funcao auxiliar local: valida se as coords estao no primeiro
    // quadrante e ate 20.0
    auto noPQ = [](double x, double y) {
        return x >= 0.0 && y >= 0.0 && x <= 20.0 && y <= 20.0;
    };

    // Verifica se as quatro coordenadas estao no primeiro quadrante
    if (!noPQ(a,b) || !noPQ(c,d) || !noPQ(e,f) || !noPQ(g,h)) {
        cout << "Erro: alguma coordenada fora do 1o quadrante "
             << "ou maior que 20. Usando default unitario." << endl;
        x1=0; y1=0; x2=1; y2=0; x3=1; y3=1; x4=0; y4=1;
        return;
    }

    // Verifica se realmente forma um retangulo alinhado aos eixos.
    // Assumindo a ordem: (xLE,yIE), (xRE,yIE), (xRE,ySE), (xLE,ySE)
    // ou seja: lados horizontais e verticais.
    bool ok = (b == d) && (f == h) && (a == g) && (c == e);
    // Tambem: os dois "x" devem ser distintos e os dois "y" tambem
    ok = ok && (a != c) && (b != f);

    if (!ok) {
        cout << "Erro: as 4 coordenadas nao formam um retangulo "
             << "alinhado aos eixos. Usando default unitario." << endl;
        x1=0; y1=0; x2=1; y2=0; x3=1; y3=1; x4=0; y4=1;
        return;
    }

    x1=a; y1=b; x2=c; y2=d; x3=e; y3=f; x4=g; y4=h;
}

double RetanguloAvancado::comprimento() const {
    double dim1 = fabs(x2 - x1);   // base
    double dim2 = fabs(y3 - y2);   // altura
    return (dim1 > dim2) ? dim1 : dim2;
}

double RetanguloAvancado::largura() const {
    double dim1 = fabs(x2 - x1);
    double dim2 = fabs(y3 - y2);
    return (dim1 < dim2) ? dim1 : dim2;
}

double RetanguloAvancado::perimetro() const {
    return 2.0 * (comprimento() + largura());
}

double RetanguloAvancado::area() const {
    return comprimento() * largura();
}

bool RetanguloAvancado::quadrado() const {
    return fabs(comprimento() - largura()) < 1e-9;
}

double RetanguloAvancado::getX1() const { return x1; }
double RetanguloAvancado::getY1() const { return y1; }
double RetanguloAvancado::getX2() const { return x2; }
double RetanguloAvancado::getY2() const { return y2; }
double RetanguloAvancado::getX3() const { return x3; }
double RetanguloAvancado::getY3() const { return y3; }
double RetanguloAvancado::getX4() const { return x4; }
double RetanguloAvancado::getY4() const { return y4; }
