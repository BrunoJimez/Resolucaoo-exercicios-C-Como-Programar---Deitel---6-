// Exercicio 17.12 - RetanguloAvancado.h
// Retangulo armazenado pelos 4 cantos cartesianos (primeiro quadrante).
// O construtor chama uma funcao set que valida tudo.
#ifndef RETANGULO_AVANCADO_H
#define RETANGULO_AVANCADO_H

class RetanguloAvancado {
public:
    // Quatro cantos: (x1,y1), (x2,y2), (x3,y3), (x4,y4)
    // Por convencao: canto inferior-esquerdo, inferior-direito,
    //                superior-direito, superior-esquerdo.
    RetanguloAvancado(double x1 = 0, double y1 = 0,
                      double x2 = 1, double y2 = 0,
                      double x3 = 1, double y3 = 1,
                      double x4 = 0, double y4 = 1);

    // Define as 4 coordenadas validando primeiro quadrante,
    // limites <= 20.0 e se realmente formam um retangulo
    void set(double x1, double y1, double x2, double y2,
             double x3, double y3, double x4, double y4);

    double comprimento() const;   // a maior das dimensoes
    double largura()    const;    // a menor das dimensoes
    double perimetro()  const;
    double area()       const;
    bool   quadrado()   const;    // predicado

    // Acesso aos cantos (para o exercicio 17.13)
    double getX1() const; double getY1() const;
    double getX2() const; double getY2() const;
    double getX3() const; double getY3() const;
    double getX4() const; double getY4() const;

private:
    double x1, y1, x2, y2, x3, y3, x4, y4;
};

#endif
