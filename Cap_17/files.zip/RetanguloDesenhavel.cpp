// Exercicio 17.13 - RetanguloDesenhavel.cpp
#include <iostream>
#include <cmath>
#include "RetanguloDesenhavel.h"
using namespace std;

RetanguloDesenhavel::RetanguloDesenhavel(double a, double b, double c, double d,
                                         double e, double f, double g, double h)
    : fillChar(' '), perimeterChar('*') {
    set(a, b, c, d, e, f, g, h);
}

void RetanguloDesenhavel::set(double a, double b, double c, double d,
                              double e, double f, double g, double h) {
    auto noPQ = [](double x, double y) {
        return x >= 0.0 && y >= 0.0 && x <= 20.0 && y <= 20.0;
    };
    bool ok = noPQ(a,b) && noPQ(c,d) && noPQ(e,f) && noPQ(g,h)
              && (b == d) && (f == h) && (a == g) && (c == e)
              && (a != c) && (b != f);
    if (!ok) {
        cout << "Erro nas coordenadas. Usando default unitario." << endl;
        x1=0; y1=0; x2=1; y2=0; x3=1; y3=1; x4=0; y4=1;
        return;
    }
    x1=a; y1=b; x2=c; y2=d; x3=e; y3=f; x4=g; y4=h;
}

void RetanguloDesenhavel::setFillCharacter(char c)      { fillChar = c; }
void RetanguloDesenhavel::setPerimeterCharacter(char c) { perimeterChar = c; }

double RetanguloDesenhavel::comprimento() const {
    double d1 = fabs(x2 - x1), d2 = fabs(y3 - y2);
    return (d1 > d2) ? d1 : d2;
}
double RetanguloDesenhavel::largura() const {
    double d1 = fabs(x2 - x1), d2 = fabs(y3 - y2);
    return (d1 < d2) ? d1 : d2;
}
double RetanguloDesenhavel::perimetro() const { return 2*(comprimento()+largura()); }
double RetanguloDesenhavel::area()      const { return comprimento()*largura(); }
bool   RetanguloDesenhavel::quadrado()  const { return fabs(comprimento()-largura())<1e-9; }

// Desenha o retangulo em uma area 25x25
void RetanguloDesenhavel::desenhar() const {
    const int LADO = 25;
    int ix1 = static_cast<int>(x1), iy1 = static_cast<int>(y1);
    int ix2 = static_cast<int>(x2), iy3 = static_cast<int>(y3);

    // Imprimimos linha por linha, do topo (y=LADO-1) para a base (y=0),
    // para que o eixo y cresca para cima como em matematica.
    for (int y = LADO - 1; y >= 0; --y) {
        for (int x = 0; x < LADO; ++x) {
            char c = '.';                       // fundo do plano
            bool naBorda  = ((x == ix1 || x == ix2) && (y >= iy1 && y <= iy3))
                         || ((y == iy1 || y == iy3) && (x >= ix1 && x <= ix2));
            bool noMiolo  = (x > ix1 && x < ix2 && y > iy1 && y < iy3);
            if      (naBorda) c = perimeterChar;
            else if (noMiolo) c = fillChar;
            cout << c;
        }
        cout << endl;
    }
}
