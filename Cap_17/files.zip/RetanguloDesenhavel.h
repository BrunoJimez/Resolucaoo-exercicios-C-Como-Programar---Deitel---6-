// Exercicio 17.13 - RetanguloDesenhavel.h
// Retangulo com desenhar() em uma caixa 25x25 do primeiro quadrante
#ifndef RETANGULO_DESENHAVEL_H
#define RETANGULO_DESENHAVEL_H

class RetanguloDesenhavel {
public:
    RetanguloDesenhavel(double x1 = 0, double y1 = 0,
                        double x2 = 1, double y2 = 0,
                        double x3 = 1, double y3 = 1,
                        double x4 = 0, double y4 = 1);

    void set(double x1, double y1, double x2, double y2,
             double x3, double y3, double x4, double y4);

    void setFillCharacter(char c);       // caractere para preencher o miolo
    void setPerimeterCharacter(char c);  // caractere para a borda

    double comprimento() const;
    double largura()    const;
    double perimetro()  const;
    double area()       const;
    bool   quadrado()   const;

    // Desenha em ASCII em uma area de 25x25 do primeiro quadrante
    void desenhar() const;

private:
    double x1, y1, x2, y2, x3, y3, x4, y4;
    char   fillChar;
    char   perimeterChar;
};

#endif
