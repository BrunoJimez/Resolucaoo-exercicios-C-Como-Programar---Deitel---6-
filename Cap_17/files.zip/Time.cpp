// Exercicio 17.4 - Time.cpp
#include <iostream>
#include <iomanip>
#include <ctime>
#include "Time.h"
using namespace std;

Time::Time(bool useCurrentTime, int h, int m, int s) {
    if (useCurrentTime) {
        time_t agora = time(nullptr);
        struct tm *partes = localtime(&agora);
        setTime(partes->tm_hour, partes->tm_min, partes->tm_sec);
    } else {
        setTime(h, m, s);
    }
}

void Time::setTime(int h, int m, int s) {
    setHour(h);
    setMinute(m);
    setSecond(s);
}

void Time::setHour(int h)   { hour   = (h >= 0 && h < 24) ? h : 0; }
void Time::setMinute(int m) { minute = (m >= 0 && m < 60) ? m : 0; }
void Time::setSecond(int s) { second = (s >= 0 && s < 60) ? s : 0; }

int Time::getHour()   const { return hour;   }
int Time::getMinute() const { return minute; }
int Time::getSecond() const { return second; }

void Time::printUniversal() const {
    cout << setfill('0') << setw(2) << hour   << ':'
         << setw(2) << minute << ':'
         << setw(2) << second;
}

void Time::printStandard() const {
    int h12 = ((hour == 0 || hour == 12) ? 12 : hour % 12);
    cout << setfill('0') << setw(2) << h12 << ':'
         << setw(2) << minute << ':' << setw(2) << second
         << (hour < 12 ? " AM" : " PM");
}
