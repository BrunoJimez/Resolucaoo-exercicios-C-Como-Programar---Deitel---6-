// Exercicio 17.4 - Time.h
// Classe Time com construtor que pode usar a hora corrente do sistema
#ifndef TIME_H
#define TIME_H

class Time {
public:
    // Construtor: se useCurrentTime=true, usa a hora atual do sistema;
    //            caso contrario, usa os valores fornecidos (default 0,0,0)
    explicit Time(bool useCurrentTime = false,
                  int h = 0, int m = 0, int s = 0);

    void setTime(int h, int m, int s);
    void setHour(int h);
    void setMinute(int m);
    void setSecond(int s);

    int getHour() const;
    int getMinute() const;
    int getSecond() const;

    void printUniversal() const;   // formato 24h: HH:MM:SS
    void printStandard() const;    // formato 12h: HH:MM:SS AM/PM

private:
    int hour;     // 0-23
    int minute;   // 0-59
    int second;   // 0-59
};

#endif
