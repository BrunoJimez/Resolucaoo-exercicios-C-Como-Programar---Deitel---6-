// Exercicio 17.7 - TimeTick.cpp
#include <iostream>
#include <iomanip>
#include "TimeTick.h"
using namespace std;

TimeTick::TimeTick(int h, int m, int s) {
    setTime(h, m, s);
}

void TimeTick::setTime(int h, int m, int s) {
    hour   = (h >= 0 && h < 24) ? h : 0;
    minute = (m >= 0 && m < 60) ? m : 0;
    second = (s >= 0 && s < 60) ? s : 0;
}

int TimeTick::getHour()   const { return hour;   }
int TimeTick::getMinute() const { return minute; }
int TimeTick::getSecond() const { return second; }

void TimeTick::tick() {
    ++second;
    if (second == 60) {
        second = 0;
        ++minute;
        if (minute == 60) {
            minute = 0;
            ++hour;
            if (hour == 24) {
                hour = 0;     // volta para 00:00:00
            }
        }
    }
}

void TimeTick::printUniversal() const {
    cout << setfill('0')
         << setw(2) << hour   << ':'
         << setw(2) << minute << ':'
         << setw(2) << second
         << setfill(' ');
}

void TimeTick::printStandard() const {
    int h12 = ((hour == 0 || hour == 12) ? 12 : hour % 12);
    cout << setfill('0')
         << setw(2) << h12    << ':'
         << setw(2) << minute << ':'
         << setw(2) << second
         << (hour < 12 ? " AM" : " PM")
         << setfill(' ');
}
