// Exercicio 17.7 - TimeTick.h
// Classe Time com funcao-membro tick que incrementa em 1 segundo
#ifndef TIMETICK_H
#define TIMETICK_H

class TimeTick {
public:
    TimeTick(int h = 0, int m = 0, int s = 0);

    void setTime(int h, int m, int s);
    int getHour() const;
    int getMinute() const;
    int getSecond() const;

    // Incrementa o tempo em 1 segundo, propagando para min/hora/dia
    void tick();

    void printUniversal() const;
    void printStandard() const;

private:
    int hour;
    int minute;
    int second;
};

#endif
