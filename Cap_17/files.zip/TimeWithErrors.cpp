// Exercicio 17.10 - TimeWithErrors.cpp
#include <iostream>
#include <iomanip>
#include "TimeWithErrors.h"
using namespace std;

TimeWithErrors::TimeWithErrors(int h, int m, int s) {
    setTime(h, m, s);
}

int TimeWithErrors::setHour(int h) {
    if (h >= 0 && h < 24) { hour = h; return SUCCESS; }
    hour = 0;
    return ERR_HOUR;
}

int TimeWithErrors::setMinute(int m) {
    if (m >= 0 && m < 60) { minute = m; return SUCCESS; }
    minute = 0;
    return ERR_MINUTE;
}

int TimeWithErrors::setSecond(int s) {
    if (s >= 0 && s < 60) { second = s; return SUCCESS; }
    second = 0;
    return ERR_SECOND;
}

int TimeWithErrors::setTime(int h, int m, int s) {
    // Combina os codigos de erro com OR bit-a-bit
    return setHour(h) | setMinute(m) | setSecond(s);
}

int TimeWithErrors::getHour()   const { return hour;   }
int TimeWithErrors::getMinute() const { return minute; }
int TimeWithErrors::getSecond() const { return second; }

void TimeWithErrors::printUniversal() const {
    cout << setfill('0')
         << setw(2) << hour   << ':'
         << setw(2) << minute << ':'
         << setw(2) << second
         << setfill(' ');
}

void TimeWithErrors::printStandard() const {
    int h12 = ((hour == 0 || hour == 12) ? 12 : hour % 12);
    cout << setfill('0')
         << setw(2) << h12    << ':'
         << setw(2) << minute << ':'
         << setw(2) << second
         << (hour < 12 ? " AM" : " PM")
         << setfill(' ');
}
