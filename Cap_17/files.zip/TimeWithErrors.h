// Exercicio 17.10 - TimeWithErrors.h
// Classe Time com setters que retornam codigo de erro
#ifndef TIMEWITHERRORS_H
#define TIMEWITHERRORS_H

class TimeWithErrors {
public:
    // Codigos de erro retornados pelos setters
    enum ErrorCode {
        SUCCESS = 0,
        ERR_HOUR   = 1,
        ERR_MINUTE = 2,
        ERR_SECOND = 4
    };

    TimeWithErrors(int h = 0, int m = 0, int s = 0);

    // Cada setter retorna 0 se OK, ou um codigo de erro != 0
    int setTime(int h, int m, int s);
    int setHour(int h);
    int setMinute(int m);
    int setSecond(int s);

    int getHour() const;
    int getMinute() const;
    int getSecond() const;

    void printUniversal() const;
    void printStandard() const;

private:
    int hour;
    int minute;
    int second;
};

#endif
