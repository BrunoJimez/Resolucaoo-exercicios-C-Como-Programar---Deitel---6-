// Exercicio 17.13 - main_RetanguloDesenhavel.cpp
#include <iostream>
#include "RetanguloDesenhavel.h"
using namespace std;

int main() {
    cout << "=== Retangulo 8x5 com borda default (*) e miolo vazio ===" << endl;
    RetanguloDesenhavel r1(3,2, 11,2, 11,7, 3,7);
    r1.desenhar();

    cout << "\n=== Mesmo retangulo, borda '#' e miolo '+' ===" << endl;
    r1.setPerimeterCharacter('#');
    r1.setFillCharacter('+');
    r1.desenhar();

    cout << "\n=== Quadrado 4x4 com borda 'X' e miolo '.' (... usa fundo!) ===" << endl;
    RetanguloDesenhavel r2(5,5, 9,5, 9,9, 5,9);
    r2.setPerimeterCharacter('X');
    r2.setFillCharacter('o');
    r2.desenhar();

    return 0;
}
