// Exercicio 17.4 - main_Time04.cpp
#include <iostream>
#include "Time.h"
using namespace std;

int main() {
    // Objeto com hora especifica
    Time t1(false, 14, 30, 25);
    cout << "Tempo especifico:\n";
    cout << "  Universal: "; t1.printUniversal(); cout << "\n";
    cout << "  Standard:  "; t1.printStandard();  cout << "\n";

    // Objeto inicializado com a hora corrente do sistema
    Time t2(true);
    cout << "\nHora corrente do sistema:\n";
    cout << "  Universal: "; t2.printUniversal(); cout << "\n";
    cout << "  Standard:  "; t2.printStandard();  cout << "\n";

    return 0;
}
