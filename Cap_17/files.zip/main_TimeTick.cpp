// Exercicio 17.7 - main_TimeTick.cpp
// Testa a funcao tick em situacoes criticas
#include <iostream>
#include "TimeTick.h"
using namespace std;

void testarTransicao(const char *etiqueta, int h, int m, int s, int qtos) {
    cout << "\n=== " << etiqueta << " ===" << endl;
    TimeTick t(h, m, s);
    cout << "Inicio: "; t.printUniversal(); cout << endl;
    for (int i = 0; i < qtos; ++i) {
        t.tick();
        cout << " Tick #" << (i+1) << ": "; t.printUniversal();
        cout << "  ("; t.printStandard(); cout << ")" << endl;
    }
}

int main() {
    // (a) Incrementar para o proximo minuto
    testarTransicao("Transicao de minuto (11:30:58 -> 11:31:00)",
                    11, 30, 58, 3);

    // (b) Incrementar para a proxima hora
    testarTransicao("Transicao de hora (08:59:58 -> 09:00:00)",
                    8, 59, 58, 3);

    // (c) Incrementar de 23:59:59 para 00:00:00
    testarTransicao("Transicao de dia (23:59:58 -> 00:00:00)",
                    23, 59, 58, 3);

    return 0;
}
