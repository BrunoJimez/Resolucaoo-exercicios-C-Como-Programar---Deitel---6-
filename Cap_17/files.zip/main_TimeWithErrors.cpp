// Exercicio 17.10 - main_TimeWithErrors.cpp
#include <iostream>
#include "TimeWithErrors.h"
using namespace std;

// Reporta texto humano para cada codigo de erro
void reportar(int code) {
    if (code == TimeWithErrors::SUCCESS) {
        cout << "  OK: valor aceito." << endl;
        return;
    }
    cout << "  ERRO (codigo " << code << "):";
    if (code & TimeWithErrors::ERR_HOUR)   cout << " hora invalida;";
    if (code & TimeWithErrors::ERR_MINUTE) cout << " minuto invalido;";
    if (code & TimeWithErrors::ERR_SECOND) cout << " segundo invalido;";
    cout << endl;
}

int main() {
    TimeWithErrors t;

    cout << "=== Tentativas validas e invalidas ===" << endl;

    cout << "\nt.setTime(10, 30, 45):" << endl;
    reportar(t.setTime(10, 30, 45));
    cout << "  Estado: "; t.printUniversal(); cout << endl;

    cout << "\nt.setTime(25, 30, 45)  [hora invalida]:" << endl;
    reportar(t.setTime(25, 30, 45));
    cout << "  Estado: "; t.printUniversal(); cout << endl;

    cout << "\nt.setTime(10, 75, 45)  [minuto invalido]:" << endl;
    reportar(t.setTime(10, 75, 45));
    cout << "  Estado: "; t.printUniversal(); cout << endl;

    cout << "\nt.setTime(10, 30, 99)  [segundo invalido]:" << endl;
    reportar(t.setTime(10, 30, 99));
    cout << "  Estado: "; t.printUniversal(); cout << endl;

    cout << "\nt.setTime(25, 75, 99)  [tudo invalido]:" << endl;
    reportar(t.setTime(25, 75, 99));
    cout << "  Estado: "; t.printUniversal(); cout << endl;

    cout << "\nt.setHour(-5)  [hora negativa]:" << endl;
    reportar(t.setHour(-5));
    cout << "  Estado: "; t.printUniversal(); cout << endl;

    return 0;
}
