// Exercicio 18.10 - Card.cpp
#include "Card.h"
using namespace std;

const string Card::faces[13] = {
    "As", "Dois", "Tres", "Quatro", "Cinco", "Seis", "Sete",
    "Oito", "Nove", "Dez", "Valete", "Dama", "Rei"
};

const string Card::suits[4] = { "Copas", "Ouros", "Paus", "Espadas" };

Card::Card(int f, int s) : face(f), suit(s) {}

int Card::getFace() const { return face; }
int Card::getSuit() const { return suit; }

string Card::toString() const {
    return faces[face] + " de " + suits[suit];
}
