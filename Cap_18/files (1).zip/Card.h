// Exercicio 18.10 - Card.h
// Representa uma carta de baralho com valor (face) e naipe (suit)
#ifndef CARD_H
#define CARD_H

#include <string>

class Card {
public:
    // 13 valores: 0=As, 1..9=2..10, 10=Valete, 11=Dama, 12=Rei
    // 4 naipes:   0=Copas, 1=Ouros, 2=Paus, 3=Espadas
    Card(int face = 0, int suit = 0);

    int getFace() const;
    int getSuit() const;
    std::string toString() const;

private:
    int face;
    int suit;

    static const std::string faces[13];
    static const std::string suits[4];
};

#endif
