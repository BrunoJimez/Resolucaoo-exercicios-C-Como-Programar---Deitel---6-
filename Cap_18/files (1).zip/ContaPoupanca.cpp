// Exercicio 18.7 - ContaPoupanca.cpp
#include "ContaPoupanca.h"

// Definicao do dado-membro static (obrigatoria fora da classe)
double ContaPoupanca::taxaJurosAnual = 0.0;

ContaPoupanca::ContaPoupanca(double saldoInicial)
    : valorConta(saldoInicial >= 0 ? saldoInicial : 0) {
}

void ContaPoupanca::calculaJurosMensais() {
    double jurosMensal = valorConta * taxaJurosAnual / 12.0;
    valorConta += jurosMensal;
}

double ContaPoupanca::getValorConta() const {
    return valorConta;
}

void ContaPoupanca::modificaTaxaJuros(double novaTaxa) {
    if (novaTaxa >= 0.0) taxaJurosAnual = novaTaxa;
}

double ContaPoupanca::getTaxaJurosAnual() {
    return taxaJurosAnual;
}
