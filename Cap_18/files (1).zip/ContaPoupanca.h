// Exercicio 18.7 - ContaPoupanca.h
// Classe com dado-membro static (taxa de juros compartilhada)
#ifndef CONTAPOUPANCA_H
#define CONTAPOUPANCA_H

class ContaPoupanca {
public:
    ContaPoupanca(double saldoInicial = 0.0);

    void calculaJurosMensais();
    double getValorConta() const;

    // Funcao-membro static: opera sobre o dado static, nao precisa de objeto
    static void modificaTaxaJuros(double novaTaxa);
    static double getTaxaJurosAnual();

private:
    double valorConta;                  // por objeto (cada cliente tem o seu)
    static double taxaJurosAnual;       // unica, compartilhada por todos
};

#endif
