// Exercicio 18.6 - Date.cpp
#include <iostream>
#include <ctime>
#include "Date.h"
using namespace std;

// Tabela estatica de nomes de meses
const string Date::nomesDosMeses[] = {
    "", "janeiro", "fevereiro", "marco", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
};

bool Date::ehBissexto(int a) {
    return (a % 4 == 0 && a % 100 != 0) || (a % 400 == 0);
}

int Date::diasDoMes(int m, int a) {
    static const int dias[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (m < 1 || m > 12) return 31;
    if (m == 2 && ehBissexto(a)) return 29;
    return dias[m - 1];
}

int Date::numeroDoMes(const string &nome) {
    for (int i = 1; i <= 12; ++i)
        if (nomesDosMeses[i] == nome) return i;
    return 1;   // se nao encontrar, retorna janeiro
}

// Construtor numerico
Date::Date(int m, int d, int a) {
    setAno(a);
    setMes(m);
    setDia(d);
}

// Construtor por nome do mes
Date::Date(const string &nomeDoMes, int d, int a) {
    setAno(a);
    setMes(numeroDoMes(nomeDoMes));
    setDia(d);
}

// Funcao de fabrica: cria Date a partir do dia do ano (juliano)
Date Date::deDiaDoAno(int diaDoAno, int a) {
    int restante = diaDoAno;
    int m = 1;
    while (m <= 12 && restante > diasDoMes(m, a)) {
        restante -= diasDoMes(m, a);
        ++m;
    }
    return Date(m, restante, a);
}

// Construtor com data do sistema (parametro booleano apenas para diferenciar)
Date::Date(bool /*usarDataDoSistema*/) {
    time_t agora = time(nullptr);
    struct tm *partes = localtime(&agora);
    setAno(partes->tm_year + 1900);   // tm_year e' anos desde 1900
    setMes(partes->tm_mon + 1);        // tm_mon e' 0-11
    setDia(partes->tm_mday);
}

void Date::setMes(int m) {
    mes = (m >= 1 && m <= 12) ? m : 1;
}
void Date::setDia(int d) {
    int max = diasDoMes(mes, ano);
    dia = (d >= 1 && d <= max) ? d : 1;
}
void Date::setAno(int a) {
    ano = (a >= 1) ? a : 2000;
}

int Date::getMes() const { return mes; }
int Date::getDia() const { return dia; }
int Date::getAno() const { return ano; }

void Date::imprimirDDMMAA() const {
    cout << (dia < 10 ? "0" : "") << dia << "/"
         << (mes < 10 ? "0" : "") << mes << "/"
         << (ano % 100 < 10 ? "0" : "") << (ano % 100);
}

void Date::imprimirDDDAAAA() const {
    // calcula o dia do ano
    int diaDoAno = dia;
    for (int m = 1; m < mes; ++m) diaDoAno += diasDoMes(m, ano);
    cout << diaDoAno << " " << ano;
}

void Date::imprimirPorExtenso() const {
    cout << dia << " de " << nomesDosMeses[mes] << " de " << ano;
}
