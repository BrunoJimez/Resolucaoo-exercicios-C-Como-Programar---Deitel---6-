// Exercicio 18.6 - Date.h
// Classe Date com multiplos formatos de saida e construtores sobrecarregados
#ifndef DATE_H
#define DATE_H

#include <string>

class Date {
public:
    // (b) Construtores sobrecarregados:
    Date(int mes = 1, int dia = 1, int ano = 2000);   // formato numerico
    Date(const std::string &nomeDoMes, int dia, int ano); // por nome do mes
    explicit Date(bool usarDataDoSistema);             // (c) data do sistema

    // Funcao de fabrica para criar Date a partir de dia do ano
    // (usada em vez de construtor para evitar ambiguidade com Date(int,int,int))
    static Date deDiaDoAno(int diaDoAno, int ano);

    void setMes(int m);
    void setDia(int d);
    void setAno(int a);
    int  getMes() const;
    int  getDia() const;
    int  getAno() const;

    // (a) Tres formatos de saida
    void imprimirDDMMAA() const;          // 14/06/92
    void imprimirDDDAAAA() const;         // 166 1992 (dia juliano)
    void imprimirPorExtenso() const;      // 14 de junho de 1992

private:
    int mes;
    int dia;
    int ano;

    static const std::string nomesDosMeses[];   // tabela compartilhada
    static int diasDoMes(int m, int ano);
    static bool ehBissexto(int a);
    static int numeroDoMes(const std::string &nome);
};

#endif
