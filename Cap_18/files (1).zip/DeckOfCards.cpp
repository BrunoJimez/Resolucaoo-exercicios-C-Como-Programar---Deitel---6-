// Exercicio 18.10 - DeckOfCards.cpp
#include <cstdlib>
#include <ctime>
#include "DeckOfCards.h"
using namespace std;

DeckOfCards::DeckOfCards() : currentCard(0) {
    // Cria as 52 cartas: 13 valores x 4 naipes
    for (int suit = 0; suit < 4; ++suit) {
        for (int face = 0; face < 13; ++face) {
            deck.push_back(Card(face, suit));
        }
    }
    // Inicializa o gerador de numeros aleatorios uma vez
    static bool seedDone = false;
    if (!seedDone) {
        srand(static_cast<unsigned>(time(nullptr)));
        seedDone = true;
    }
}

void DeckOfCards::shuffle() {
    int n = static_cast<int>(deck.size());
    for (int i = 0; i < n; ++i) {
        int j = rand() % n;             // posicao aleatoria
        Card aux = deck[i];
        deck[i] = deck[j];
        deck[j] = aux;
    }
    currentCard = 0;                    // resetar para distribuir do inicio
}

Card DeckOfCards::dealCard() {
    if (moreCards()) {
        return deck[currentCard++];
    }
    return Card();   // baralho exausto -> retorna carta default
}

bool DeckOfCards::moreCards() const {
    return currentCard < static_cast<int>(deck.size());
}

void DeckOfCards::resetDeck() {
    currentCard = 0;
}
