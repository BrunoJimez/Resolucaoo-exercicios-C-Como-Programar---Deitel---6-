// Exercicio 18.10 - DeckOfCards.h
// Baralho de 52 cartas com embaralhamento e distribuicao
#ifndef DECKOFCARDS_H
#define DECKOFCARDS_H

#include <vector>
#include "Card.h"

class DeckOfCards {
public:
    DeckOfCards();                  // cria as 52 cartas em ordem
    void shuffle();                 // embaralha aleatoriamente
    Card dealCard();                // distribui a proxima carta
    bool moreCards() const;         // ainda ha cartas no baralho?
    void resetDeck();               // recoloca currentCard em 0

private:
    std::vector<Card> deck;
    int currentCard;                // indice da proxima carta a distribuir
};

#endif
