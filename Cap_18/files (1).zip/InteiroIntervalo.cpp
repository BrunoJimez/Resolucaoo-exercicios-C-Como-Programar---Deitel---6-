// Exercicio 18.8 - InteiroIntervalo.cpp
#include <iostream>
#include "InteiroIntervalo.h"
using namespace std;

InteiroIntervalo::InteiroIntervalo()
    : a(TAMANHO, false) {            // todos false = conjunto vazio
}

InteiroIntervalo::InteiroIntervalo(const int valores[], int qtde)
    : a(TAMANHO, false) {
    for (int i = 0; i < qtde; ++i) insereElemento(valores[i]);
}

InteiroIntervalo InteiroIntervalo::uniaoConjuntos(
        const InteiroIntervalo &o) const {
    InteiroIntervalo r;
    for (int i = 0; i < TAMANHO; ++i)
        r.a[i] = a[i] || o.a[i];
    return r;
}

InteiroIntervalo InteiroIntervalo::intersecaoConjuntos(
        const InteiroIntervalo &o) const {
    InteiroIntervalo r;
    for (int i = 0; i < TAMANHO; ++i)
        r.a[i] = a[i] && o.a[i];
    return r;
}

void InteiroIntervalo::insereElemento(int k) {
    if (k >= 0 && k < TAMANHO) a[k] = true;
}

void InteiroIntervalo::deletaElemento(int m) {
    if (m >= 0 && m < TAMANHO) a[m] = false;
}

void InteiroIntervalo::imprimeConjunto() const {
    bool vazio = true;
    for (int i = 0; i < TAMANHO; ++i) {
        if (a[i]) {
            cout << i << " ";
            vazio = false;
        }
    }
    if (vazio) cout << "---";
    cout << endl;
}

bool InteiroIntervalo::eIguala(const InteiroIntervalo &o) const {
    for (int i = 0; i < TAMANHO; ++i)
        if (a[i] != o.a[i]) return false;
    return true;
}
