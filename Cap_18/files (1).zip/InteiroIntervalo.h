// Exercicio 18.8 - InteiroIntervalo.h
// Conjunto de inteiros no intervalo 0..100 usando vector<bool>
#ifndef INTEIROINTERVALO_H
#define INTEIROINTERVALO_H

#include <vector>

class InteiroIntervalo {
public:
    static const int TAMANHO = 101;     // suporta 0..100

    InteiroIntervalo();                                       // construtor default: vazio
    InteiroIntervalo(const int valores[], int qtde);          // a partir de array

    InteiroIntervalo uniaoConjuntos(const InteiroIntervalo &o) const;
    InteiroIntervalo intersecaoConjuntos(const InteiroIntervalo &o) const;

    void insereElemento(int k);
    void deletaElemento(int m);

    void imprimeConjunto() const;
    bool eIguala(const InteiroIntervalo &o) const;

private:
    std::vector<bool> a;
};

#endif
