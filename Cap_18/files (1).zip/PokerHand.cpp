// Exercicio 18.11 - PokerHand.cpp
#include <iostream>
#include <algorithm>
#include "PokerHand.h"
using namespace std;

PokerHand::PokerHand(const vector<Card> &cartas) : mao(cartas) {}

void PokerHand::contarValores(int contagens[13]) const {
    for (int i = 0; i < 13; ++i) contagens[i] = 0;
    for (const Card &c : mao) ++contagens[c.getFace()];
}

bool PokerHand::temPar() const {
    int c[13]; contarValores(c);
    for (int i = 0; i < 13; ++i) if (c[i] == 2) return true;
    return false;
}

bool PokerHand::temDoisPares() const {
    int c[13]; contarValores(c);
    int pares = 0;
    for (int i = 0; i < 13; ++i) if (c[i] == 2) ++pares;
    return pares >= 2;
}

bool PokerHand::temTrincaIguais() const {
    int c[13]; contarValores(c);
    for (int i = 0; i < 13; ++i) if (c[i] == 3) return true;
    return false;
}

bool PokerHand::temQuadra() const {
    int c[13]; contarValores(c);
    for (int i = 0; i < 13; ++i) if (c[i] == 4) return true;
    return false;
}

bool PokerHand::temFlush() const {
    if (mao.empty()) return false;
    int naipe = mao[0].getSuit();
    for (const Card &c : mao)
        if (c.getSuit() != naipe) return false;
    return true;
}

bool PokerHand::temStraight() const {
    vector<int> faces;
    for (const Card &c : mao) faces.push_back(c.getFace());
    sort(faces.begin(), faces.end());

    // sequencia normal
    bool seq = true;
    for (size_t i = 1; i < faces.size(); ++i)
        if (faces[i] != faces[i-1] + 1) { seq = false; break; }
    if (seq) return true;

    // caso especial: A-2-3-4-5 (As baixo). As tem face=0.
    if (faces == vector<int>{0, 1, 2, 3, 4}) return true;
    // caso especial: A-K-Q-J-10 (As alto)
    if (faces == vector<int>{0, 9, 10, 11, 12}) return true;
    return false;
}

int PokerHand::classificar() const {
    bool fl = temFlush();
    bool st = temStraight();
    if (fl && st)       return 8;
    if (temQuadra())    return 7;
    if (temTrincaIguais() && temPar()) return 6;   // full house
    if (fl)             return 5;
    if (st)             return 4;
    if (temTrincaIguais()) return 3;
    if (temDoisPares()) return 2;
    if (temPar())       return 1;
    return 0;
}

string PokerHand::nomeDaClassificacao() const {
    switch (classificar()) {
        case 8: return "Straight Flush";
        case 7: return "Quadra";
        case 6: return "Full House";
        case 5: return "Flush";
        case 4: return "Straight";
        case 3: return "Trinca";
        case 2: return "Dois Pares";
        case 1: return "Um Par";
        default: return "Carta Alta";
    }
}

void PokerHand::imprimir() const {
    for (const Card &c : mao)
        cout << "  " << c.toString() << endl;
}
