// Exercicio 18.11 - PokerHand.h
// Analisa uma mao de 5 cartas e detecta combinacoes
#ifndef POKERHAND_H
#define POKERHAND_H

#include <vector>
#include <string>
#include "Card.h"

class PokerHand {
public:
    static const int TAMANHO_MAO = 5;

    explicit PokerHand(const std::vector<Card> &cartas);

    bool temPar() const;
    bool temDoisPares() const;
    bool temTrincaIguais() const;
    bool temQuadra() const;
    bool temFlush() const;
    bool temStraight() const;

    // Classifica a mao em uma escala numerica para comparacao
    // (maior = mao melhor):
    //   8 = straight flush, 7 = quadra, 6 = full house,
    //   5 = flush, 4 = straight, 3 = trinca,
    //   2 = dois pares, 1 = um par, 0 = nada
    int classificar() const;
    std::string nomeDaClassificacao() const;

    void imprimir() const;

private:
    std::vector<Card> mao;

    // Conta quantas cartas h\'a de cada valor (0..12)
    void contarValores(int contagens[13]) const;
};

#endif
