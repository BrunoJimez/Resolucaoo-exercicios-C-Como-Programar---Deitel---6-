// Exercicio 18.9 - TimeSegundos.cpp
#include <iostream>
#include <iomanip>
#include "TimeSegundos.h"
using namespace std;

TimeSegundos::TimeSegundos(int h, int m, int s) {
    setTime(h, m, s);
}

void TimeSegundos::setTime(int h, int m, int s) {
    // Valida e converte para total de segundos em uma so passagem
    if (h < 0 || h >= 24) h = 0;
    if (m < 0 || m >= 60) m = 0;
    if (s < 0 || s >= 60) s = 0;
    totalSegundos = h * 3600 + m * 60 + s;
}

void TimeSegundos::setHour(int h) {
    int m = getMinute(), s = getSecond();
    if (h < 0 || h >= 24) h = 0;
    totalSegundos = h * 3600 + m * 60 + s;
}

void TimeSegundos::setMinute(int m) {
    int h = getHour(), s = getSecond();
    if (m < 0 || m >= 60) m = 0;
    totalSegundos = h * 3600 + m * 60 + s;
}

void TimeSegundos::setSecond(int s) {
    int h = getHour(), m = getMinute();
    if (s < 0 || s >= 60) s = 0;
    totalSegundos = h * 3600 + m * 60 + s;
}

int TimeSegundos::getHour()   const { return totalSegundos / 3600; }
int TimeSegundos::getMinute() const { return (totalSegundos % 3600) / 60; }
int TimeSegundos::getSecond() const { return totalSegundos % 60; }

void TimeSegundos::printUniversal() const {
    cout << setfill('0')
         << setw(2) << getHour()   << ':'
         << setw(2) << getMinute() << ':'
         << setw(2) << getSecond()
         << setfill(' ');
}

void TimeSegundos::printStandard() const {
    int h = getHour();
    int h12 = ((h == 0 || h == 12) ? 12 : h % 12);
    cout << setfill('0')
         << setw(2) << h12         << ':'
         << setw(2) << getMinute() << ':'
         << setw(2) << getSecond()
         << (h < 12 ? " AM" : " PM")
         << setfill(' ');
}
