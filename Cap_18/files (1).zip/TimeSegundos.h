// Exercicio 18.9 - TimeSegundos.h
// Mesma interface publica do Time, mas internamente guarda APENAS
// um inteiro: total de segundos desde meia-noite
#ifndef TIMESEGUNDOS_H
#define TIMESEGUNDOS_H

class TimeSegundos {
public:
    TimeSegundos(int h = 0, int m = 0, int s = 0);

    // Mesmos setters / getters da interface tradicional
    void setTime(int h, int m, int s);
    void setHour(int h);
    void setMinute(int m);
    void setSecond(int s);

    int getHour() const;
    int getMinute() const;
    int getSecond() const;

    void printUniversal() const;
    void printStandard() const;

private:
    // UNICO dado-membro - representacao radicalmente diferente,
    // mas o cliente nao percebe a mudanca!
    int totalSegundos;     // 0 a 86399
};

#endif
