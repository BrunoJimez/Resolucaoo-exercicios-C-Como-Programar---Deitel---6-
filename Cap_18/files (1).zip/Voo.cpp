// Exercicio 18.15 - Voo.cpp
#include <iostream>
#include <sstream>
#include "Voo.h"
using namespace std;

Voo::Voo(const string &c, const string &n,
         const string &fab, const string &mod,
         const string &o, const string &d,
         int alt, int vel)
    : companhia(c), numero(n), fabricante(fab), modelo(mod),
      origem(o), destino(d), altitudeAtual(alt),
      novaAltitude(alt), velocidade(vel), status(ESTACIONADO) {
}

void Voo::setCompanhia(const string &c) { companhia = c; }
string Voo::getCompanhia() const { return companhia; }
void Voo::setNumero(const string &n) { numero = n; }
string Voo::getNumero() const { return numero; }
void Voo::setOrigem(const string &o) { origem = o; }
string Voo::getOrigem() const { return origem; }
void Voo::setDestino(const string &d) { destino = d; }
string Voo::getDestino() const { return destino; }
void Voo::setStatus(StatusVoo s) { status = s; }
Voo::StatusVoo Voo::getStatus() const { return status; }
int Voo::getAltitudeAtual() const { return altitudeAtual; }
int Voo::getNovaAltitude() const { return novaAltitude; }
int Voo::getVelocidade() const { return velocidade; }

void Voo::mudaAltitude(int novaAlt) {
    cout << "[ATC->" << companhia << " " << numero
         << "] mudaAltitude: alt. atual=" << altitudeAtual
         << " pes, nova alt.=" << novaAlt << " pes." << endl;
    status = MUDA_ALTITUDE;
    novaAltitude = novaAlt;
}

void Voo::reduzVelocidade(int novaVel) {
    cout << "[ATC->" << companhia << " " << numero
         << "] reduzVelocidade: vel. atual=" << velocidade
         << " nos, nova vel.=" << novaVel << " nos." << endl;
    status = REDUZ_VELOCIDADE;
    velocidade = novaVel;
}

void Voo::iniciaPouso() {
    cout << "[ATC->" << companhia << " " << numero
         << "] iniciaPouso: iniciando descida final em "
         << destino << "." << endl;
    status = INICIANDO_POUSO;
    novaAltitude = 0;
}

void Voo::taxiar() {
    cout << "[ATC->" << companhia << " " << numero
         << "] taxiar: liberado para taxiamento." << endl;
    status = TAXIANDO;
}

void Voo::decolar() {
    cout << "[ATC->" << companhia << " " << numero
         << "] decolar: pista liberada, decolando de "
         << origem << " com destino a " << destino << "." << endl;
    status = DECOLANDO;
}

string Voo::statusParaString(StatusVoo s) {
    switch (s) {
        case ESTACIONADO:          return "ESTACIONADO";
        case TAXIANDO:             return "TAXIANDO";
        case AGUARDANDO_DECOLAGEM: return "AGUARDANDO_DECOLAGEM";
        case DECOLANDO:            return "DECOLANDO";
        case SUBINDO:              return "SUBINDO";
        case EM_CRUZEIRO:          return "EM_CRUZEIRO";
        case MUDA_ALTITUDE:        return "MUDA_ALTITUDE";
        case REDUZ_VELOCIDADE:     return "REDUZ_VELOCIDADE";
        case INICIANDO_POUSO:      return "INICIANDO_POUSO";
        case POUSANDO:             return "POUSANDO";
        case POUSADO:              return "POUSADO";
    }
    return "DESCONHECIDO";
}

string Voo::toString() const {
    ostringstream oss;
    oss << "Voo " << companhia << " " << numero
        << " (" << fabricante << " " << modelo << ")"
        << "\n    " << origem << " -> " << destino
        << "  alt=" << altitudeAtual << "pes"
        << "  vel=" << velocidade << "nos"
        << "  status=" << statusParaString(status);
    return oss.str();
}
