// Exercicio 18.15 - Voo.h (Fazendo a Diferenca)
// Classe Voo para simulacao de controle de trafego aereo
#ifndef VOO_H
#define VOO_H

#include <string>

class Voo {
public:
    // Enumeracao para representar os estados de um voo
    enum StatusVoo {
        ESTACIONADO,
        TAXIANDO,
        AGUARDANDO_DECOLAGEM,
        DECOLANDO,
        SUBINDO,
        EM_CRUZEIRO,
        MUDA_ALTITUDE,
        REDUZ_VELOCIDADE,
        INICIANDO_POUSO,
        POUSANDO,
        POUSADO
    };

    Voo(const std::string &companhia, const std::string &numero,
        const std::string &fabricante, const std::string &modelo,
        const std::string &origem, const std::string &destino,
        int altitudeAtual = 0, int velocidade = 0);

    // Setters / getters
    void setCompanhia(const std::string &c);
    std::string getCompanhia() const;
    void setNumero(const std::string &n);
    std::string getNumero() const;
    void setOrigem(const std::string &o);
    std::string getOrigem() const;
    void setDestino(const std::string &d);
    std::string getDestino() const;
    void setStatus(StatusVoo s);
    StatusVoo getStatus() const;
    int  getAltitudeAtual() const;
    int  getNovaAltitude() const;
    int  getVelocidade() const;

    // Comportamentos (mensagens que o ATC envia ao voo)
    void mudaAltitude(int novaAlt);
    void reduzVelocidade(int novaVel);
    void iniciaPouso();
    void taxiar();
    void decolar();

    std::string toString() const;
    static std::string statusParaString(StatusVoo s);

private:
    std::string companhia;
    std::string numero;
    std::string fabricante;
    std::string modelo;
    std::string origem;        // codigo IATA de 3 letras
    std::string destino;       // codigo IATA de 3 letras
    int altitudeAtual;         // em pes
    int novaAltitude;          // altitude objetivo apos comando ATC
    int velocidade;            // em nos
    StatusVoo status;
};

#endif
