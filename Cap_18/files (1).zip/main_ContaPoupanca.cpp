// Exercicio 18.7 - main_ContaPoupanca.cpp
#include <iostream>
#include <iomanip>
#include "ContaPoupanca.h"
using namespace std;

int main() {
    cout << fixed << setprecision(2);

    // Cria dois correntistas
    ContaPoupanca economia1(2000.00);
    ContaPoupanca economia2(3000.00);

    cout << "=== Saldos iniciais ===" << endl;
    cout << "  economia1: R$ " << economia1.getValorConta() << endl;
    cout << "  economia2: R$ " << economia2.getValorConta() << endl;

    // Taxa de 3% ao ano
    ContaPoupanca::modificaTaxaJuros(0.03);
    cout << "\n=== Taxa de juros anual definida como "
         << (ContaPoupanca::getTaxaJurosAnual() * 100) << "% ===" << endl;

    economia1.calculaJurosMensais();
    economia2.calculaJurosMensais();
    cout << "Apos juros mensais (taxa 3% a.a.):" << endl;
    cout << "  economia1: R$ " << economia1.getValorConta() << endl;
    cout << "  economia2: R$ " << economia2.getValorConta() << endl;

    // Taxa muda para 4% ao ano
    ContaPoupanca::modificaTaxaJuros(0.04);
    cout << "\n=== Taxa de juros anual alterada para "
         << (ContaPoupanca::getTaxaJurosAnual() * 100) << "% ===" << endl;

    economia1.calculaJurosMensais();
    economia2.calculaJurosMensais();
    cout << "Apos juros mensais (taxa 4% a.a.):" << endl;
    cout << "  economia1: R$ " << economia1.getValorConta() << endl;
    cout << "  economia2: R$ " << economia2.getValorConta() << endl;

    return 0;
}
