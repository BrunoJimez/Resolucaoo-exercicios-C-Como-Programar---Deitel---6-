// Exercicio 18.6 - main_Date.cpp
#include <iostream>
#include "Date.h"
using namespace std;

void exibir(const char *etiqueta, const Date &d) {
    cout << etiqueta << endl;
    cout << "  DD/MM/AA       : "; d.imprimirDDMMAA();      cout << endl;
    cout << "  DDD AAAA       : "; d.imprimirDDDAAAA();     cout << endl;
    cout << "  Por extenso    : "; d.imprimirPorExtenso();  cout << endl;
}

int main() {
    cout << "=== Construtor numerico (14/6/1992) ===" << endl;
    Date d1(6, 14, 1992);
    exibir("d1:", d1);

    cout << "\n=== Construtor por nome do mes ===" << endl;
    Date d2("junho", 14, 1992);
    exibir("d2:", d2);

    cout << "\n=== Funcao de fabrica por dia do ano (166 de 1992) ===" << endl;
    Date d3 = Date::deDiaDoAno(166, 1992);   // 166 = 14 de junho em 1992
    exibir("d3:", d3);

    cout << "\n=== Construtor com data do sistema ===" << endl;
    Date hoje(true);
    exibir("hoje:", hoje);

    return 0;
}
