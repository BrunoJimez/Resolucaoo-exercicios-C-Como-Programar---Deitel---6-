// Exercicio 18.10 - main_Deck.cpp
#include <iostream>
#include <iomanip>
#include "DeckOfCards.h"
using namespace std;

int main() {
    DeckOfCards baralho;
    baralho.shuffle();

    cout << "=== Distribuindo todas as 52 cartas ===" << endl;
    int contador = 0;
    while (baralho.moreCards()) {
        Card c = baralho.dealCard();
        cout << setw(22) << left << c.toString();
        if (++contador % 4 == 0) cout << endl;
    }

    return 0;
}
