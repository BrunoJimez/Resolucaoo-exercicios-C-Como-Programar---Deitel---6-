// Exercicio 18.8 - main_InteiroIntervalo.cpp
#include <iostream>
#include "InteiroIntervalo.h"
using namespace std;

int main() {
    cout << "=== Construtores ===" << endl;
    InteiroIntervalo c1;            // vazio
    cout << "c1 (vazio): "; c1.imprimeConjunto();

    int v1[] = {1, 3, 5, 7, 9};
    InteiroIntervalo c2(v1, 5);
    cout << "c2 = {1,3,5,7,9}: "; c2.imprimeConjunto();

    int v2[] = {2, 3, 4, 5, 6};
    InteiroIntervalo c3(v2, 5);
    cout << "c3 = {2,3,4,5,6}: "; c3.imprimeConjunto();

    cout << "\n=== Operacoes ===" << endl;
    InteiroIntervalo uniao = c2.uniaoConjuntos(c3);
    cout << "c2 uniao c3:        "; uniao.imprimeConjunto();

    InteiroIntervalo intersec = c2.intersecaoConjuntos(c3);
    cout << "c2 intersec c3:     "; intersec.imprimeConjunto();

    cout << "\n=== insereElemento / deletaElemento ===" << endl;
    c1.insereElemento(50);
    c1.insereElemento(75);
    c1.insereElemento(100);
    cout << "c1 apos inserir 50,75,100: "; c1.imprimeConjunto();
    c1.deletaElemento(75);
    cout << "c1 apos deletar 75:        "; c1.imprimeConjunto();

    cout << "\n=== Igualdade ===" << endl;
    InteiroIntervalo c4(v1, 5);
    cout << "c2 == c4 (mesmos elementos)? "
         << (c2.eIguala(c4) ? "SIM" : "NAO") << endl;
    cout << "c2 == c3?                    "
         << (c2.eIguala(c3) ? "SIM" : "NAO") << endl;

    return 0;
}
