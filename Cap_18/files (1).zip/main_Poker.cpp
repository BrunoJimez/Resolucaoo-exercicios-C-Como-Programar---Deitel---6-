// Exercicio 18.11 - main_Poker.cpp
// Testa funcoes de classificacao de poker com maos especificas
#include <iostream>
#include "PokerHand.h"
using namespace std;

void analisar(const char *etiqueta, const vector<Card> &cartas) {
    PokerHand mao(cartas);
    cout << "\n=== " << etiqueta << " ===" << endl;
    mao.imprimir();
    cout << "  -> Classificacao: " << mao.nomeDaClassificacao()
         << " (nivel " << mao.classificar() << ")" << endl;
}

int main() {
    // Um par (dois "Reis")
    analisar("Um par de Reis",
             {Card(12,0), Card(12,1), Card(3,2), Card(7,0), Card(9,3)});

    // Dois pares
    analisar("Dois pares (Reis e Damas)",
             {Card(12,0), Card(12,1), Card(11,2), Card(11,3), Card(5,0)});

    // Trinca
    analisar("Trinca de Valetes",
             {Card(10,0), Card(10,1), Card(10,2), Card(4,3), Card(8,0)});

    // Quadra
    analisar("Quadra de Ases",
             {Card(0,0), Card(0,1), Card(0,2), Card(0,3), Card(5,0)});

    // Flush
    analisar("Flush de Copas",
             {Card(2,0), Card(5,0), Card(7,0), Card(9,0), Card(11,0)});

    // Straight (sequencia 5-6-7-8-9)
    analisar("Straight 5-6-7-8-9",
             {Card(4,0), Card(5,1), Card(6,2), Card(7,3), Card(8,0)});

    // Straight Flush
    analisar("Straight Flush 5-9 de Copas",
             {Card(4,0), Card(5,0), Card(6,0), Card(7,0), Card(8,0)});

    // Full House
    analisar("Full House (3 Reis e 2 Damas)",
             {Card(12,0), Card(12,1), Card(12,2), Card(11,0), Card(11,1)});

    // Nada
    analisar("Carta alta (nada)",
             {Card(2,0), Card(5,1), Card(8,2), Card(11,3), Card(3,0)});

    return 0;
}
