// Exercicio 18.12 - main_PokerCompara.cpp
// Distribui duas maos de 5 cartas e compara
#include <iostream>
#include "DeckOfCards.h"
#include "PokerHand.h"
using namespace std;

vector<Card> distribuir5(DeckOfCards &b) {
    vector<Card> v;
    for (int i = 0; i < 5 && b.moreCards(); ++i)
        v.push_back(b.dealCard());
    return v;
}

int main() {
    DeckOfCards baralho;
    baralho.shuffle();

    PokerHand jogador1(distribuir5(baralho));
    PokerHand jogador2(distribuir5(baralho));

    cout << "=== Mao do Jogador 1 ===" << endl;
    jogador1.imprimir();
    cout << "  -> " << jogador1.nomeDaClassificacao()
         << " (nivel " << jogador1.classificar() << ")" << endl;

    cout << "\n=== Mao do Jogador 2 ===" << endl;
    jogador2.imprimir();
    cout << "  -> " << jogador2.nomeDaClassificacao()
         << " (nivel " << jogador2.classificar() << ")" << endl;

    cout << "\n=== Resultado ===" << endl;
    int n1 = jogador1.classificar();
    int n2 = jogador2.classificar();
    if      (n1 > n2) cout << ">>> Jogador 1 venceu! <<<" << endl;
    else if (n2 > n1) cout << ">>> Jogador 2 venceu! <<<" << endl;
    else              cout << ">>> Empate de classificacao (desempate por "
                              "carta alta nao implementado) <<<" << endl;

    return 0;
}
