// Exercicio 18.13 - main_PokerDistribuidor.cpp
// O distribuidor (computador) avalia sua mao e decide trocar 1, 2 ou 3 cartas
#include <iostream>
#include <algorithm>
#include "DeckOfCards.h"
#include "PokerHand.h"
using namespace std;

vector<Card> distribuir5(DeckOfCards &b) {
    vector<Card> v;
    for (int i = 0; i < 5 && b.moreCards(); ++i)
        v.push_back(b.dealCard());
    return v;
}

// Decide quantas cartas trocar com base na classificacao atual:
//   carta alta  (0) -> trocar 3 (as 3 piores)
//   um par      (1) -> trocar 3 (mantem o par)
//   dois pares  (2) -> trocar 1 (mantem os pares)
//   trinca      (3) -> trocar 2 (mantem a trinca)
//   acima       -> trocar 0
int decidirQuantasTrocar(int classif) {
    switch (classif) {
        case 0: return 3;
        case 1: return 3;
        case 2: return 1;
        case 3: return 2;
        default: return 0;
    }
}

// Identifica indices das cartas a descartar.
// Estrategia simples: descartar as menores de face que NAO contribuem
// para a melhor combinacao existente.
vector<int> escolherDescarte(const vector<Card> &mao, int quantas) {
    // contagens por face
    int c[13] = {0};
    for (const Card &k : mao) ++c[k.getFace()];

    // criar vetor de pares (peso, indice) onde peso menor = pior carta
    // Peso = 100 * (frequencia da face) + face. Cartas isoladas com
    // face baixa terao menor peso (sao descartadas primeiro).
    vector<pair<int,int>> pesos;
    for (int i = 0; i < (int)mao.size(); ++i) {
        int p = 100 * c[mao[i].getFace()] + mao[i].getFace();
        pesos.push_back({p, i});
    }
    sort(pesos.begin(), pesos.end());

    vector<int> descarte;
    for (int i = 0; i < quantas; ++i) descarte.push_back(pesos[i].second);
    return descarte;
}

vector<Card> trocarCartas(const vector<Card> &mao,
                          const vector<int> &indicesDescarte,
                          DeckOfCards &b) {
    vector<Card> nova = mao;
    for (int idx : indicesDescarte) {
        if (b.moreCards()) nova[idx] = b.dealCard();
    }
    return nova;
}

int main() {
    DeckOfCards baralho;
    baralho.shuffle();

    vector<Card> mao = distribuir5(baralho);
    PokerHand original(mao);
    cout << "=== Mao original do distribuidor ===" << endl;
    original.imprimir();
    cout << "  -> " << original.nomeDaClassificacao() << endl;

    int quantas = decidirQuantasTrocar(original.classificar());
    cout << "\nDistribuidor decide trocar " << quantas << " carta(s)." << endl;

    if (quantas > 0) {
        vector<int> descarte = escolherDescarte(mao, quantas);
        cout << "Cartas a descartar (indices): ";
        for (int i : descarte) cout << i << " ";
        cout << endl;

        vector<Card> novaMao = trocarCartas(mao, descarte, baralho);
        PokerHand nova(novaMao);

        cout << "\n=== Nova mao apos a troca ===" << endl;
        nova.imprimir();
        cout << "  -> " << nova.nomeDaClassificacao()
             << " (nivel " << nova.classificar() << ")" << endl;
    }

    return 0;
}
