// Exercicio 18.14 - main_PokerJogador.cpp
// Jogador humano joga contra o distribuidor (computador).
// O jogador escolhe quais cartas trocar.
#include <iostream>
#include <algorithm>
#include "DeckOfCards.h"
#include "PokerHand.h"
using namespace std;

vector<Card> distribuir5(DeckOfCards &b) {
    vector<Card> v;
    for (int i = 0; i < 5 && b.moreCards(); ++i)
        v.push_back(b.dealCard());
    return v;
}

int decidirQuantasTrocar(int classif) {
    switch (classif) {
        case 0: return 3;
        case 1: return 3;
        case 2: return 1;
        case 3: return 2;
        default: return 0;
    }
}

vector<int> escolherDescarteComputador(const vector<Card> &mao, int quantas) {
    int c[13] = {0};
    for (const Card &k : mao) ++c[k.getFace()];
    vector<pair<int,int>> pesos;
    for (int i = 0; i < (int)mao.size(); ++i) {
        int p = 100 * c[mao[i].getFace()] + mao[i].getFace();
        pesos.push_back({p, i});
    }
    sort(pesos.begin(), pesos.end());
    vector<int> descarte;
    for (int i = 0; i < quantas; ++i) descarte.push_back(pesos[i].second);
    return descarte;
}

void imprimirComIndices(const vector<Card> &mao) {
    for (int i = 0; i < (int)mao.size(); ++i)
        cout << "  [" << i << "] " << mao[i].toString() << endl;
}

int main() {
    DeckOfCards baralho;
    baralho.shuffle();

    vector<Card> maoJogador     = distribuir5(baralho);
    vector<Card> maoComputador  = distribuir5(baralho);

    cout << "=== Sua mao ===" << endl;
    imprimirComIndices(maoJogador);
    PokerHand mj(maoJogador);
    cout << "  -> " << mj.nomeDaClassificacao() << endl;

    cout << "\nQuantas cartas voce quer trocar (0-3)? ";
    int n;
    cin >> n;
    if (n < 0) n = 0;
    if (n > 3) n = 3;

    if (n > 0) {
        cout << "Digite os " << n << " indices (0-4) das cartas a trocar: ";
        vector<int> descarte(n);
        for (int i = 0; i < n; ++i) cin >> descarte[i];
        for (int idx : descarte) {
            if (idx >= 0 && idx < 5 && baralho.moreCards())
                maoJogador[idx] = baralho.dealCard();
        }
    }

    // Vez do computador
    PokerHand mc(maoComputador);
    int qComp = decidirQuantasTrocar(mc.classificar());
    if (qComp > 0) {
        vector<int> dc = escolherDescarteComputador(maoComputador, qComp);
        for (int idx : dc)
            if (baralho.moreCards())
                maoComputador[idx] = baralho.dealCard();
    }

    // Avaliacao final
    PokerHand mjFinal(maoJogador);
    PokerHand mcFinal(maoComputador);

    cout << "\n=== Sua mao final ===" << endl;
    mjFinal.imprimir();
    cout << "  -> " << mjFinal.nomeDaClassificacao() << endl;

    cout << "\n=== Mao do computador ===" << endl;
    mcFinal.imprimir();
    cout << "  -> " << mcFinal.nomeDaClassificacao() << endl;

    cout << "\n=== Resultado ===" << endl;
    int nv1 = mjFinal.classificar();
    int nv2 = mcFinal.classificar();
    if (nv1 > nv2)      cout << ">>> Voce venceu! <<<" << endl;
    else if (nv2 > nv1) cout << ">>> Computador venceu! <<<" << endl;
    else                cout << ">>> Empate (mesma classificacao) <<<" << endl;

    return 0;
}
