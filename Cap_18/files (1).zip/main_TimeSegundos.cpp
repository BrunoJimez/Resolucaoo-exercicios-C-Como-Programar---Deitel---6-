// Exercicio 18.9 - main_TimeSegundos.cpp
// Mesmo programa cliente que funcionaria com a versao tradicional:
// a mudanca interna eh totalmente invisivel.
#include <iostream>
#include "TimeSegundos.h"
using namespace std;

int main() {
    TimeSegundos t1(14, 30, 25);

    cout << "=== Demonstrando que a interface eh identica ===" << endl;
    cout << "Tempo:" << endl;
    cout << "  Universal: "; t1.printUniversal(); cout << endl;
    cout << "  Standard:  "; t1.printStandard();  cout << endl;

    cout << "\n=== Setters individuais funcionam normalmente ===" << endl;
    t1.setHour(8);
    cout << "Apos setHour(8):    "; t1.printUniversal(); cout << endl;
    t1.setMinute(15);
    cout << "Apos setMinute(15): "; t1.printUniversal(); cout << endl;
    t1.setSecond(45);
    cout << "Apos setSecond(45): "; t1.printUniversal(); cout << endl;

    cout << "\n=== Getters retornam valores corretos ===" << endl;
    cout << "getHour()   = " << t1.getHour()   << endl;
    cout << "getMinute() = " << t1.getMinute() << endl;
    cout << "getSecond() = " << t1.getSecond() << endl;

    cout << "\n=== Validacao no setter (igual ao tradicional) ===" << endl;
    t1.setTime(25, 99, 99);     // tudo invalido
    cout << "Apos setTime(25,99,99): "; t1.printUniversal(); cout << endl;

    return 0;
}
