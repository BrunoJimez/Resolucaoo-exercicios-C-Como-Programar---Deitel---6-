// Exercicio 18.15 - main_Voo.cpp
// Simulacao de controle de trafego aereo com 3 voos em estados distintos
#include <iostream>
#include "Voo.h"
using namespace std;

int main() {
    cout << "============================================" << endl;
    cout << "       SimulacaoControleTrafegoAereo        " << endl;
    cout << "============================================" << endl;

    // Tres voos em estados distintos
    Voo voo1("LATAM",  "JJ3101", "Airbus", "A320",
             "GRU", "BSB", 0, 0);             // estacionado em Guarulhos
    Voo voo2("Gol",    "G31524", "Boeing", "737-800",
             "CGH", "SDU", 32000, 480);       // em cruzeiro
    Voo voo3("Azul",   "AD4002", "Embraer", "E195",
             "VCP", "REC", 12000, 250);       // preparando-se para pousar

    cout << "\n--- Estado inicial dos voos ---" << endl;
    cout << voo1.toString() << endl;
    cout << voo2.toString() << endl;
    cout << voo3.toString() << endl;

    cout << "\n--- ATC envia comandos ---\n" << endl;

    // Voo 1 inicia partida: taxia e decola
    voo1.taxiar();
    voo1.decolar();

    // Voo 2 muda altitude e reduz velocidade
    voo2.mudaAltitude(28000);
    voo2.reduzVelocidade(420);

    // Voo 3 inicia procedimento de pouso
    voo3.iniciaPouso();

    cout << "\n--- Estado final dos voos ---" << endl;
    cout << voo1.toString() << endl;
    cout << voo2.toString() << endl;
    cout << voo3.toString() << endl;

    return 0;
}
