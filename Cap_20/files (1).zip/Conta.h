// Exercicio 20.10 - Conta.h
// Classe-base para hierarquia de contas bancarias
#ifndef CONTA_H
#define CONTA_H

class Conta {
public:
    Conta(double saldoInicial);

    void   creditar(double valor);
    // debitar retorna bool (a dica do enunciado!):
    // true  se o dinheiro foi efetivamente retirado;
    // false se o valor de debito ultrapassou o saldo (saldo nao muda).
    bool   debitar(double valor);
    double retSaldo() const;

protected:
    double saldo;     // protected: classes derivadas podem ler diretamente
};

#endif
