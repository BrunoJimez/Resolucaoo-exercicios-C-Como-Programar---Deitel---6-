// Exercicio 20.10 - ContaCorrente.cpp
#include "ContaCorrente.h"

ContaCorrente::ContaCorrente(double saldoInicial, double t)
    : Conta(saldoInicial) {
    setTaxaTransacao(t);
}

void ContaCorrente::setTaxaTransacao(double t) {
    taxaPorTransacao = (t >= 0.0) ? t : 0.0;
}
double ContaCorrente::getTaxaTransacao() const { return taxaPorTransacao; }

// Credito: chama a versao base e SUBTRAI a taxa do saldo
void ContaCorrente::creditar(double valor) {
    Conta::creditar(valor);                   // delega para a base
    saldo -= taxaPorTransacao;                // cobra a taxa
}

// Debito: chama a base; cobra taxa apenas se o debito ocorreu
bool ContaCorrente::debitar(double valor) {
    bool ok = Conta::debitar(valor);
    if (ok) saldo -= taxaPorTransacao;
    return ok;
}
