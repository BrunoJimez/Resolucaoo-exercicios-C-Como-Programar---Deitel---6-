// Exercicio 20.10 - ContaCorrente.h
// Herda da Conta e REDEFINE creditar/debitar para cobrar taxa
// por transacao bem-sucedida.
#ifndef CONTACORRENTE_H
#define CONTACORRENTE_H

#include "Conta.h"

class ContaCorrente : public Conta {
public:
    ContaCorrente(double saldoInicial, double taxaTransacao);

    void   setTaxaTransacao(double t);
    double getTaxaTransacao() const;

    // Redefine: subtrai a taxa apos a transacao bem-sucedida
    void creditar(double valor);
    bool debitar(double valor);

private:
    double taxaPorTransacao;
};

#endif
