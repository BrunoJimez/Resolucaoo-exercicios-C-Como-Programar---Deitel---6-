// Exercicio 20.10 - ContaPoupanca.cpp
#include "ContaPoupanca.h"

ContaPoupanca::ContaPoupanca(double saldoInicial, double taxa)
    : Conta(saldoInicial) {
    setTaxaJuros(taxa);
}

void ContaPoupanca::setTaxaJuros(double t) {
    taxaJurosAnual = (t >= 0.0) ? t : 0.0;
}
double ContaPoupanca::getTaxaJuros() const { return taxaJurosAnual; }

double ContaPoupanca::calculaJuros() const {
    return saldo * taxaJurosAnual;
}
