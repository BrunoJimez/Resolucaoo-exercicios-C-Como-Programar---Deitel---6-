// Exercicio 20.10 - ContaPoupanca.h
// Herda da Conta; usa creditar/debitar SEM redefinir.
// Adiciona taxaJurosAnual e calculaJuros.
#ifndef CONTAPOUPANCA20_H
#define CONTAPOUPANCA20_H

#include "Conta.h"

class ContaPoupanca : public Conta {
public:
    ContaPoupanca(double saldoInicial, double taxaJurosAnual);

    void   setTaxaJuros(double t);
    double getTaxaJuros() const;
    double calculaJuros() const;        // retorna saldo * taxa

private:
    double taxaJurosAnual;
};

#endif
