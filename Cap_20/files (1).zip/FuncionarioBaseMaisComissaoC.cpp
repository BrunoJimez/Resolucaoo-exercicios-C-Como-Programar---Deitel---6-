// Exercicio 20.3 - FuncionarioBaseMaisComissaoC.cpp
#include <iostream>
#include <iomanip>
#include "FuncionarioBaseMaisComissaoC.h"
using namespace std;

FuncionarioBaseMaisComissaoC::FuncionarioBaseMaisComissaoC(
        const string &p, const string &s, const string &c,
        double vb, double t, double sb)
    : funcionarioBase(p, s, c, vb, t) {
    setSalarioBase(sb);
}

// Cada acesso requer DELEGACAO explicita ao objeto membro:
void FuncionarioBaseMaisComissaoC::setPrimeiroNome(const string &p) {
    funcionarioBase.setPrimeiroNome(p);
}
string FuncionarioBaseMaisComissaoC::getPrimeiroNome() const {
    return funcionarioBase.getPrimeiroNome();
}
void FuncionarioBaseMaisComissaoC::setSobrenome(const string &s) {
    funcionarioBase.setSobrenome(s);
}
string FuncionarioBaseMaisComissaoC::getSobrenome() const {
    return funcionarioBase.getSobrenome();
}
void FuncionarioBaseMaisComissaoC::setCPF(const string &c) {
    funcionarioBase.setCPF(c);
}
string FuncionarioBaseMaisComissaoC::getCPF() const {
    return funcionarioBase.getCPF();
}
void FuncionarioBaseMaisComissaoC::setVendasBrutas(double vb) {
    funcionarioBase.setVendasBrutas(vb);
}
double FuncionarioBaseMaisComissaoC::getVendasBrutas() const {
    return funcionarioBase.getVendasBrutas();
}
void FuncionarioBaseMaisComissaoC::setTaxaComissao(double t) {
    funcionarioBase.setTaxaComissao(t);
}
double FuncionarioBaseMaisComissaoC::getTaxaComissao() const {
    return funcionarioBase.getTaxaComissao();
}

void FuncionarioBaseMaisComissaoC::setSalarioBase(double sb) {
    salarioBase = (sb >= 0.0) ? sb : 0.0;
}
double FuncionarioBaseMaisComissaoC::getSalarioBase() const {
    return salarioBase;
}

double FuncionarioBaseMaisComissaoC::rendimentos() const {
    return funcionarioBase.rendimentos() + salarioBase;
}

void FuncionarioBaseMaisComissaoC::imprimir() const {
    cout << "Funcionario base+comissao (composicao):\n  ";
    funcionarioBase.imprimir();
    cout << "\n  Salario base:   R$ " << fixed << setprecision(2) << salarioBase;
}
