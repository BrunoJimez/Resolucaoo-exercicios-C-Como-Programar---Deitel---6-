// Exercicio 20.3 - FuncionarioBaseMaisComissaoC.h
// VERSAO POR COMPOSICAO: FuncionarioBaseMaisComissao "tem-um"
// FuncionarioComissao como membro, mais um salario base proprio.
#ifndef FBC_COMPOSICAO_H
#define FBC_COMPOSICAO_H

#include "FuncionarioComissao.h"

class FuncionarioBaseMaisComissaoC {
public:
    FuncionarioBaseMaisComissaoC(const std::string &p,
                                 const std::string &s,
                                 const std::string &c,
                                 double vb, double t,
                                 double salarioBase);

    // Como NAO herdamos, precisamos REPETIR ou DELEGAR cada
    // getter/setter publico de FuncionarioComissao!
    void setPrimeiroNome(const std::string &p);
    std::string getPrimeiroNome() const;
    void setSobrenome(const std::string &s);
    std::string getSobrenome() const;
    void setCPF(const std::string &c);
    std::string getCPF() const;
    void setVendasBrutas(double vb);
    double getVendasBrutas() const;
    void setTaxaComissao(double t);
    double getTaxaComissao() const;

    void   setSalarioBase(double sb);
    double getSalarioBase() const;

    double rendimentos() const;
    void   imprimir() const;

private:
    FuncionarioComissao funcionarioBase;   // <-- "TEM-UM" (composicao)
    double salarioBase;
};

#endif
