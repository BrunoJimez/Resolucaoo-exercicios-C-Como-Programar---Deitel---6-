// Exercicio 20.3 - FuncionarioBaseMaisComissaoH.cpp
#include <iostream>
#include <iomanip>
#include "FuncionarioBaseMaisComissaoH.h"
using namespace std;

FuncionarioBaseMaisComissaoH::FuncionarioBaseMaisComissaoH(
        const string &p, const string &s, const string &c,
        double vb, double t, double sb)
    : FuncionarioComissao(p, s, c, vb, t) {     // chama o construtor base
    setSalarioBase(sb);
}

void FuncionarioBaseMaisComissaoH::setSalarioBase(double sb) {
    salarioBase = (sb >= 0.0) ? sb : 0.0;
}
double FuncionarioBaseMaisComissaoH::getSalarioBase() const {
    return salarioBase;
}

double FuncionarioBaseMaisComissaoH::rendimentos() const {
    // Chama a versao base via :: para reaproveitar a logica
    return FuncionarioComissao::rendimentos() + salarioBase;
}

void FuncionarioBaseMaisComissaoH::imprimir() const {
    cout << "Funcionario base+comissao (heranca):\n  ";
    FuncionarioComissao::imprimir();
    cout << "\n  Salario base:   R$ " << fixed << setprecision(2) << salarioBase;
}
