// Exercicio 20.3 - FuncionarioBaseMaisComissaoH.h
// VERSAO POR HERANCA: FuncionarioBaseMaisComissao "e-um" FuncionarioComissao
// com salario base adicional.
#ifndef FBC_HERANCA_H
#define FBC_HERANCA_H

#include "FuncionarioComissao.h"

class FuncionarioBaseMaisComissaoH : public FuncionarioComissao {
public:
    FuncionarioBaseMaisComissaoH(const std::string &p,
                                 const std::string &s,
                                 const std::string &c,
                                 double vb, double t,
                                 double salarioBase);

    void   setSalarioBase(double sb);
    double getSalarioBase() const;

    // Redefine para somar o salario base
    double rendimentos() const;
    void   imprimir() const;

private:
    double salarioBase;
};

#endif
