// Exercicio 20.3 - FuncionarioComissao.cpp
#include <iostream>
#include <iomanip>
#include "FuncionarioComissao.h"
using namespace std;

FuncionarioComissao::FuncionarioComissao(const string &p, const string &s,
                                         const string &c,
                                         double vb, double t)
    : primeiroNome(p), sobrenome(s), cpf(c) {
    setVendasBrutas(vb);
    setTaxaComissao(t);
}

void FuncionarioComissao::setPrimeiroNome(const string &p) { primeiroNome = p; }
string FuncionarioComissao::getPrimeiroNome() const { return primeiroNome; }
void FuncionarioComissao::setSobrenome(const string &s) { sobrenome = s; }
string FuncionarioComissao::getSobrenome() const { return sobrenome; }
void FuncionarioComissao::setCPF(const string &c) { cpf = c; }
string FuncionarioComissao::getCPF() const { return cpf; }

void FuncionarioComissao::setVendasBrutas(double vb) {
    vendasBrutas = (vb >= 0.0) ? vb : 0.0;
}
double FuncionarioComissao::getVendasBrutas() const { return vendasBrutas; }

void FuncionarioComissao::setTaxaComissao(double t) {
    taxaComissao = (t > 0.0 && t < 1.0) ? t : 0.0;
}
double FuncionarioComissao::getTaxaComissao() const { return taxaComissao; }

double FuncionarioComissao::rendimentos() const {
    return vendasBrutas * taxaComissao;
}

void FuncionarioComissao::imprimir() const {
    cout << "Funcionario por comissao: " << primeiroNome << " " << sobrenome
         << "\n  CPF:            " << cpf
         << "\n  Vendas brutas:  R$ " << fixed << setprecision(2) << vendasBrutas
         << "\n  Taxa comissao:  " << taxaComissao;
}
