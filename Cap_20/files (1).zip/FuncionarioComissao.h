// Exercicio 20.3 (versao com HERANCA) - FuncionarioComissao.h
// Classe-base usada por ambas as variantes
#ifndef FUNCIONARIO_COMISSAO_H
#define FUNCIONARIO_COMISSAO_H

#include <string>

class FuncionarioComissao {
public:
    FuncionarioComissao(const std::string &primeiro,
                        const std::string &sobrenome,
                        const std::string &cpf,
                        double vendasBrutas, double taxaComissao);

    void setPrimeiroNome(const std::string &p);
    std::string getPrimeiroNome() const;
    void setSobrenome(const std::string &s);
    std::string getSobrenome() const;
    void setCPF(const std::string &c);
    std::string getCPF() const;

    void setVendasBrutas(double vb);    // valida: >= 0
    double getVendasBrutas() const;
    void setTaxaComissao(double t);     // valida: 0 < t < 1
    double getTaxaComissao() const;

    double rendimentos() const;
    void   imprimir() const;

private:
    std::string primeiroNome;
    std::string sobrenome;
    std::string cpf;
    double vendasBrutas;
    double taxaComissao;
};

#endif
