// Exercicio 20.9 - Pacote.cpp
#include <iostream>
#include <iomanip>
#include "Pacote.h"
using namespace std;

Pacote::Pacote(const string &nR, const string &eR,
               const string &cR, const string &esR, const string &cepR,
               const string &nD, const string &eD,
               const string &cD, const string &esD, const string &cepD,
               double p, double c)
    : nomeRemetente(nR), enderecoRemetente(eR),
      cidadeRemetente(cR), estadoRemetente(esR), cepRemetente(cepR),
      nomeDestinatario(nD), enderecoDestinatario(eD),
      cidadeDestinatario(cD), estadoDestinatario(esD), cepDestinatario(cepD) {
    setPeso(p);
    setCustoPorGrama(c);
}

void Pacote::setPeso(double p) {
    peso = (p >= 0.0) ? p : 0.0;
}
double Pacote::getPeso() const { return peso; }

void Pacote::setCustoPorGrama(double c) {
    custoPorGrama = (c >= 0.0) ? c : 0.0;
}
double Pacote::getCustoPorGrama() const { return custoPorGrama; }

double Pacote::calculaCusto() const {
    return peso * custoPorGrama;
}

void Pacote::imprimirCabecalho() const {
    cout << "Remetente:    " << nomeRemetente << ", " << enderecoRemetente
         << ", " << cidadeRemetente << "-" << estadoRemetente
         << ", CEP " << cepRemetente << endl;
    cout << "Destinatario: " << nomeDestinatario << ", " << enderecoDestinatario
         << ", " << cidadeDestinatario << "-" << estadoDestinatario
         << ", CEP " << cepDestinatario << endl;
    cout << fixed;
    cout << "Peso: " << setprecision(2) << peso << " g  |  Custo/g: R$ "
         << setprecision(3) << custoPorGrama << endl;
}
