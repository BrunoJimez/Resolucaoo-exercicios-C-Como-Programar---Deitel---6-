// Exercicio 20.9 - Pacote.h
// Classe-base para hierarquia de pacotes de entrega
#ifndef PACOTE_H
#define PACOTE_H

#include <string>

class Pacote {
public:
    Pacote(const std::string &nomeRem, const std::string &endRem,
           const std::string &cidadeRem, const std::string &estadoRem,
           const std::string &cepRem,
           const std::string &nomeDest, const std::string &endDest,
           const std::string &cidadeDest, const std::string &estadoDest,
           const std::string &cepDest,
           double pesoG, double custoPorG);

    // Setters e getters: peso e custoPorGrama validados (>= 0)
    void setPeso(double p);
    double getPeso() const;
    void setCustoPorGrama(double c);
    double getCustoPorGrama() const;

    // Funcao publica de calculo de custo (sera redefinida pelas derivadas)
    double calculaCusto() const;

    void imprimirCabecalho() const;

protected:
    // protected: as derivadas podem acessar diretamente
    double peso;            // em gramas
    double custoPorGrama;

private:
    std::string nomeRemetente,    enderecoRemetente;
    std::string cidadeRemetente,  estadoRemetente, cepRemetente;
    std::string nomeDestinatario, enderecoDestinatario;
    std::string cidadeDestinatario, estadoDestinatario, cepDestinatario;
};

#endif
