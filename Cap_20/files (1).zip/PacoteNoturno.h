// Exercicio 20.9 - PacoteNoturno.h
// Derivada: soma taxa por grama ao custo/g padrao
#ifndef PACOTENOTURNO_H
#define PACOTENOTURNO_H

#include "Pacote.h"

class PacoteNoturno : public Pacote {
public:
    PacoteNoturno(const std::string &nR, const std::string &eR,
                  const std::string &cR, const std::string &esR,
                  const std::string &cepR,
                  const std::string &nD, const std::string &eD,
                  const std::string &cD, const std::string &esD,
                  const std::string &cepD,
                  double pesoG, double custoPorG,
                  double taxaAdicionalPorG);

    void setTaxaAdicional(double t);   // >= 0
    double getTaxaAdicional() const;

    // Redefine: soma a taxa ao custo/g antes de multiplicar pelo peso
    double calculaCusto() const;

private:
    double taxaAdicionalPorGrama;
};

#endif
