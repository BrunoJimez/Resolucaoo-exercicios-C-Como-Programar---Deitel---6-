// Exercicio 20.10 - main_Conta.cpp
#include <iostream>
#include <iomanip>
#include "Conta.h"
#include "ContaPoupanca.h"
#include "ContaCorrente.h"
using namespace std;

int main() {
    cout << fixed << setprecision(2);

    cout << "=== Conta basica ===" << endl;
    Conta c(100.00);
    cout << "Saldo inicial: R$ " << c.retSaldo() << endl;
    c.creditar(50.00);
    cout << "Apos creditar 50:    R$ " << c.retSaldo() << endl;
    c.debitar(30.00);
    cout << "Apos debitar 30:     R$ " << c.retSaldo() << endl;
    cout << "Tentativa debitar 500 (excede saldo):" << endl;
    c.debitar(500.00);
    cout << "Saldo apos tentativa: R$ " << c.retSaldo() << endl;

    cout << "\n=== ContaPoupanca (saldo 2000, juros 3% a.a.) ===" << endl;
    ContaPoupanca cp(2000.00, 0.03);
    cout << "Saldo inicial:    R$ " << cp.retSaldo() << endl;
    double juros = cp.calculaJuros();
    cout << "Juros calculados: R$ " << juros << endl;
    cp.creditar(juros);                    // soma os juros chamando creditar
    cout << "Saldo apos credito de juros: R$ " << cp.retSaldo()
         << "   (esperado 2060.00)" << endl;

    cout << "\n=== ContaCorrente (saldo 1000, taxa R$ 2 por transacao) ===" << endl;
    ContaCorrente cc(1000.00, 2.00);
    cout << "Saldo inicial: R$ " << cc.retSaldo() << endl;

    cc.creditar(200.00);
    cout << "Apos creditar 200: R$ " << cc.retSaldo()
         << "  (esperado 1000+200-2 = 1198)" << endl;

    cc.debitar(500.00);
    cout << "Apos debitar 500:  R$ " << cc.retSaldo()
         << "  (esperado 1198-500-2 = 696)" << endl;

    cout << "Tentativa debitar 10000 (excede saldo): " << endl;
    cc.debitar(10000.00);
    cout << "Saldo apos tentativa (sem taxa, pois nao houve debito): R$ "
         << cc.retSaldo() << endl;

    return 0;
}
