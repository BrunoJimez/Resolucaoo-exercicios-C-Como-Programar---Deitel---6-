// Exercicio 20.3 - main_Func.cpp
// Demonstra que AMBAS as versoes (heranca e composicao) produzem
// resultados identicos para o cliente.
#include <iostream>
#include <iomanip>
#include "FuncionarioBaseMaisComissaoH.h"
#include "FuncionarioBaseMaisComissaoC.h"
using namespace std;

int main() {
    cout << fixed << setprecision(2);

    // ===== Versao por HERANCA =====
    cout << "=== Versao por HERANCA ===" << endl;
    FuncionarioBaseMaisComissaoH funcH("Ana", "Silva", "111.222.333-44",
                                       10000.00, 0.06, 300.00);
    funcH.imprimir();
    cout << "\n  Rendimentos:    R$ " << funcH.rendimentos() << endl;

    // ===== Versao por COMPOSICAO =====
    cout << "\n=== Versao por COMPOSICAO ===" << endl;
    FuncionarioBaseMaisComissaoC funcC("Ana", "Silva", "111.222.333-44",
                                       10000.00, 0.06, 300.00);
    funcC.imprimir();
    cout << "\n  Rendimentos:    R$ " << funcC.rendimentos() << endl;

    // ===== Demonstracao da diferenca para o cliente =====
    cout << "\n=== Diferenca em uma funcao polimorfica ===" << endl;
    cout << "(A versao por HERANCA permite passar funcH a uma funcao\n"
            " que recebe FuncionarioComissao&; a por COMPOSICAO NAO.)" << endl;

    FuncionarioComissao &refBase = funcH;
    cout << "Heranca: pode tratar funcH como FuncionarioComissao&.\n"
            "  Rendimentos via referencia base: R$ "
         << refBase.rendimentos() << " (chama versao base, sem salarioBase!)"
         << endl;

    return 0;
}
