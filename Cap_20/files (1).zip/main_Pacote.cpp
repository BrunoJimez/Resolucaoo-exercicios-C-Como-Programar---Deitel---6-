// Exercicio 20.9 - main_Pacote.cpp
#include <iostream>
#include <iomanip>
#include "Pacote.h"
#include "PacoteDoisDias.h"
#include "PacoteNoturno.h"
using namespace std;

void custo(double v) {
    cout << "  -> Custo: R$ " << fixed << setprecision(2) << v << endl;
}

int main() {
    cout << "=== Pacote padrao (R$ 0.02/g x 1500 g) ===" << endl;
    Pacote p1("Maria Souza", "Rua A, 100", "Sao Paulo", "SP", "01000-000",
              "Joao Silva", "Av. B, 250", "Rio de Janeiro", "RJ", "20000-000",
              1500.0, 0.02);
    p1.imprimirCabecalho();
    custo(p1.calculaCusto());
    cout << "     (esperado: 1500 * 0.02 = R$ 30.00)" << endl;

    cout << "\n=== PacoteDoisDias (custo padrao + taxa fixa R$ 15.00) ===" << endl;
    PacoteDoisDias p2("Ana Costa", "Rua C, 5", "Belo Horizonte", "MG", "30000-000",
                      "Pedro Lima", "Av. D, 8", "Salvador", "BA", "40000-000",
                      2000.0, 0.025, 15.00);
    p2.imprimirCabecalho();
    custo(p2.calculaCusto());
    cout << "     (esperado: 2000 * 0.025 + 15 = R$ 65.00)" << endl;

    cout << "\n=== PacoteNoturno (taxa adicional R$ 0.01/g) ===" << endl;
    PacoteNoturno p3("Carlos Mendes", "Rua E, 12", "Recife", "PE", "50000-000",
                     "Lucia Pereira", "Av. F, 20", "Curitiba", "PR", "80000-000",
                     500.0, 0.03, 0.01);
    p3.imprimirCabecalho();
    custo(p3.calculaCusto());
    cout << "     (esperado: 500 * (0.03 + 0.01) = R$ 20.00)" << endl;

    return 0;
}
