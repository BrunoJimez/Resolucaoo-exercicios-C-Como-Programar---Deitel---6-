// Exercicio 23.16 - Complex.cpp
#include <iostream>
#include <sstream>
#include <string>
#include <cctype>
#include "Complex.h"
using namespace std;

Complex::Complex(int r, int i) : real(r), imaginary(i) {}

// Saida: "a + bi" se b >= 0; "a - bi" se b < 0
ostream &operator<<(ostream &out, const Complex &c) {
    if (out.fail()) return out;
    out << c.real;
    if (c.imaginary >= 0)
        out << " + " << c.imaginary << "i";
    else
        out << " - " << (-c.imaginary) << "i";
    return out;
}

// Entrada: tenta parser robusto. Aceita formatos como:
//   "3 + 8i", "3+8i", "3", "8i", "-3 - 8i", "+5i", "3 + i" (b=1), etc.
//
// Estrategia: ler a linha toda, fazer parsing manual.
istream &operator>>(istream &in, Complex &c) {
    // Le todos os caracteres ate o fim do stream
    string s;
    char ch;
    while (in.get(ch)) s.push_back(ch);

    // Remove espacos
    string t;
    for (char x : s) if (!isspace(static_cast<unsigned char>(x))) t.push_back(x);

    if (t.empty()) { in.clear(ios::failbit); return in; }

    int r = 0, i = 0;
    bool temReal = false, temImag = false;

    // Encontra a posicao do segundo operador (+ ou -) que NAO esteja
    // na primeira posicao (pois primeiro op pode ser sinal de a).
    size_t split = string::npos;
    for (size_t k = 1; k < t.size(); ++k) {
        if (t[k] == '+' || t[k] == '-') {
            split = k;
            break;
        }
    }

    string parteA, parteB;
    if (split == string::npos) {
        // Sem segundo operador: tudo eh real OU tudo eh imaginario
        if (!t.empty() && t.back() == 'i') {
            parteB = t;            // "8i" ou "-8i"
        } else {
            parteA = t;            // "3" ou "-3"
        }
    } else {
        parteA = t.substr(0, split);
        parteB = t.substr(split);
    }

    // Parser de inteiro com sinal (string vazia -> 0)
    auto parseInt = [](const string &s, int &out) -> bool {
        if (s.empty()) { out = 0; return true; }
        size_t k = 0;
        int sinal = 1;
        if (s[k] == '+') { ++k; }
        else if (s[k] == '-') { sinal = -1; ++k; }
        if (k == s.size()) return false;     // so' o sinal
        int valor = 0;
        for (; k < s.size(); ++k) {
            if (s[k] < '0' || s[k] > '9') return false;
            valor = valor * 10 + (s[k] - '0');
        }
        out = sinal * valor;
        return true;
    };

    // parteA (real, opcional)
    if (!parteA.empty()) {
        if (!parseInt(parteA, r)) { in.clear(ios::failbit); return in; }
        temReal = true;
    }

    // parteB (imaginario, opcional). Deve terminar com 'i'.
    if (!parteB.empty()) {
        if (parteB.back() != 'i') { in.clear(ios::failbit); return in; }
        string semI = parteB.substr(0, parteB.size() - 1);
        // Casos especiais: "i" -> 1, "+i" -> 1, "-i" -> -1
        if (semI.empty())                { i = 1;  temImag = true; }
        else if (semI == "+")            { i = 1;  temImag = true; }
        else if (semI == "-")            { i = -1; temImag = true; }
        else {
            if (!parseInt(semI, i)) { in.clear(ios::failbit); return in; }
            temImag = true;
        }
    }

    if (!temReal && !temImag) { in.clear(ios::failbit); return in; }

    c.real      = r;
    c.imaginary = i;
    // Sucesso: limpa qualquer eofbit/failbit que tenha vindo de in.get()
    // ao percorrer todo o stream. Isso permite que iss.fail() volte false.
    in.clear();
    return in;
}
