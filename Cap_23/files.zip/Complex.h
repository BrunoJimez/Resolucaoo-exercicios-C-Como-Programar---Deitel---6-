// Exercicio 23.16 - Complex.h
// Classe Complex com I/O sobrecarregado.
// Formato de entrada: "a + bi" ou "a - bi", com a/b possivelmente
// negativos ou ausentes (default 0).
// Saida: "a + bi" ou "a - bi" (com sinal correto).
#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>

class Complex {
    friend std::ostream &operator<<(std::ostream &, const Complex &);
    friend std::istream &operator>>(std::istream &, Complex &);
public:
    Complex(int r = 0, int i = 0);
private:
    int real;
    int imaginary;
};

#endif
