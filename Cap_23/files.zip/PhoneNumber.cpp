// Exercicio 23.14 - PhoneNumber.cpp
#include <iostream>
#include <string>
#include "PhoneNumber.h"
using namespace std;

PhoneNumber::PhoneNumber() : areaCode(""), exchange(""), line("") {}

// Saida no formato: (11) 5555-1212
ostream &operator<<(ostream &out, const PhoneNumber &t) {
    out << "(" << t.areaCode << ") " << t.exchange << "-" << t.line;
    return out;
}

istream &operator>>(istream &in, PhoneNumber &t) {
    char buffer[16] = {0};

    // (a) Le exatamente 14 caracteres no formato: "(XX) XXXX-XXXX"
    // (areaCode de 2 digitos como nos exemplos brasileiros do enunciado)
    in.read(buffer, 14);

    if (in.gcount() < 14) {
        in.clear(ios::failbit);
        return in;
    }
    buffer[14] = '\0';

    // Verifica estrutura: ( X X ) _ X X X X - X X X X
    //                    0 1 2 3 4 5 6 7 8 9 10 11 12 13
    if (buffer[0] != '(' || buffer[3] != ')' || buffer[4] != ' '
        || buffer[9] != '-') {
        in.clear(ios::failbit);
        return in;
    }

    // Extrai as 3 partes
    string area    (buffer + 1, 2);     // posicoes 1,2
    string exch    (buffer + 5, 4);     // posicoes 5..8
    string line_str(buffer + 10, 4);    // posicoes 10..13

    // Verifica que sao todos digitos
    auto soDigitos = [](const string &s) {
        for (char c : s)
            if (c < '0' || c > '9') return false;
        return true;
    };

    if (!soDigitos(area) || !soDigitos(exch) || !soDigitos(line_str)) {
        in.clear(ios::failbit);
        return in;
    }

    // (b) Primeiro digito do areaCode != 0 e != 1
    if (area[0] == '0' || area[0] == '1') {
        in.clear(ios::failbit);
        return in;
    }

    // (b) Primeiro digito do exchange != 0 e != 1
    if (exch[0] == '0' || exch[0] == '1') {
        in.clear(ios::failbit);
        return in;
    }

    // (c) Digito do meio do areaCode (segundo digito) eh 0 ou 1
    if (area[1] != '0' && area[1] != '1') {
        in.clear(ios::failbit);
        return in;
    }

    // Tudo valido: armazena
    t.areaCode = area;
    t.exchange = exch;
    t.line     = line_str;
    return in;
}
