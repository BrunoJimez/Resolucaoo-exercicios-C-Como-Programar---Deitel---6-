// Exercicio 23.14 - PhoneNumber.h
// Telefone no formato "(11) 5555-1212" -- com validacoes:
//  (a) total de 15 caracteres
//  (b) areaCode e exchange nao comecam com 0 nem 1
//  (c) digito do meio do areaCode eh 0 ou 1
#ifndef PHONENUMBER_H
#define PHONENUMBER_H

#include <iostream>
#include <string>

class PhoneNumber {
    friend std::ostream &operator<<(std::ostream &, const PhoneNumber &);
    friend std::istream &operator>>(std::istream &, PhoneNumber &);
public:
    PhoneNumber();
private:
    std::string areaCode;     // 2 digitos: "11"
    std::string exchange;     // 4 digitos: "5555"
    std::string line;         // 4 digitos: "1212"
};

#endif
