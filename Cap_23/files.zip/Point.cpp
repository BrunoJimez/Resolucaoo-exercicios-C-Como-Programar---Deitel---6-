// Exercicio 23.15 - Point.cpp
#include <iostream>
#include "Point.h"
using namespace std;

Point::Point(int x, int y) : xCoordinate(x), yCoordinate(y) {}

// Saida: "(x, y)" -- mas SO se o stream esta em estado OK
ostream &operator<<(ostream &out, const Point &p) {
    if (out.fail()) return out;   // nao exibe se ja' tem erro
    out << "(" << p.xCoordinate << ", " << p.yCoordinate << ")";
    return out;
}

// Entrada: "(x, y)" -- valida formato; em erro, set failbit
istream &operator>>(istream &in, Point &p) {
    char abrePar, virgula, fechaPar;
    int x, y;

    in >> abrePar >> x >> virgula >> y >> fechaPar;

    if (in.fail()) return in;   // ja' falhou nas leituras

    if (abrePar != '(' || virgula != ',' || fechaPar != ')') {
        in.clear(ios::failbit);
        return in;
    }

    p.xCoordinate = x;
    p.yCoordinate = y;
    return in;
}
