// Exercicio 23.15 - Point.h
// Classe Point com I/O sobrecarregado.
// Formato de entrada: "(x, y)" com x e y inteiros.
// Em erro de entrada, set failbit; em erro o operator<< nao exibe.
#ifndef POINT_H
#define POINT_H

#include <iostream>

class Point {
    friend std::ostream &operator<<(std::ostream &, const Point &);
    friend std::istream &operator>>(std::istream &, Point &);
public:
    Point(int x = 0, int y = 0);
private:
    int xCoordinate;
    int yCoordinate;
};

#endif
