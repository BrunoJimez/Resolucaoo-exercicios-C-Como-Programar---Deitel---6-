// Exercicio 23.10 - arredondamento.cpp
// Imprime 100.453627 arredondado para:
//   - inteiro (digito mais proximo)
//   - decimo
//   - centesimo
//   - milesimo
//   - decimo de milesimo
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double valor = 100.453627;

    cout << fixed;
    cout << "Valor original: " << setprecision(6) << valor << endl;
    cout << endl;
    cout << "Arredondado para:" << endl;
    cout << "  Inteiro (mais proximo):    "
         << setprecision(0) << valor << endl;
    cout << "  Decimo:                    "
         << setprecision(1) << valor << endl;
    cout << "  Centesimo:                 "
         << setprecision(2) << valor << endl;
    cout << "  Milesimo:                  "
         << setprecision(3) << valor << endl;
    cout << "  Decimo de milesimo:        "
         << setprecision(4) << valor << endl;

    cout << "\nObservacao: o arredondamento depende da implementacao;" << endl;
    cout << "tipicamente segue IEEE 754 round-half-to-even (banker's rounding)."
         << endl;

    return 0;
}
