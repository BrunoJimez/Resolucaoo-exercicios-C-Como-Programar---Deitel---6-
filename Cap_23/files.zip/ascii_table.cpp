// Exercicio 23.17 - ascii_table.cpp
// Tabela ASCII de 33 a 126: caractere, decimal, octal, hex
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    cout << "+---------+---------+---------+---------+" << endl;
    cout << "|   Char  | Decimal |  Octal  |   Hex   |" << endl;
    cout << "+---------+---------+---------+---------+" << endl;

    for (int code = 33; code <= 126; ++code) {
        cout << "|"
             << setw(6) << static_cast<char>(code) << "   |"
             << dec << setw(7) << code << "  |"
             << oct << setw(7) << code << "  |"
             << hex << setw(7) << code << "  |"
             << dec << endl;
    }
    cout << "+---------+---------+---------+---------+" << endl;
    return 0;
}
