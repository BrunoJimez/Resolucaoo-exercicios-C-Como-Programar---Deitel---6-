// Exercicio 23.7 - dec_oct_hex.cpp
// Testa entrada de inteiros em formatos decimal, octal e hexadecimal.
// Imprime cada inteiro lido nos tres formatos.
#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

void mostrarNasTresBases(int valor) {
    cout << "  Decimal:     " << dec << valor << endl;
    cout << "  Octal:       " << oct << valor << endl;
    cout << "  Hexadecimal: " << hex << valor << endl;
    cout << dec;   // restaura o padrao
}

int main() {
    // Para reprodutibilidade, usamos stringstream com os tres
    // valores literais do enunciado: 10, 010, 0x10.
    // Em C++, o manipulador `dec` (default) ignora prefixos;
    // mas com `oct` e `hex` ATIVOS, ele tenta interpretar.
    // Para REALMENTE detectar o prefixo, usamos hex/oct adequadamente.

    cout << "=== Entrada interpretada conforme o manipulador atual ===" << endl;

    // Forma 1: cada leitura definindo explicitamente a base
    int a, b, c;
    istringstream entrada1("10");      // dec
    istringstream entrada2("010");     // oct (sem o 0 inicial, vira 10)
    istringstream entrada3("0x10");    // hex (sem 0x, vira 10)

    entrada1 >> dec >> a;              // le 10 em decimal -> 10
    entrada2 >> oct >> b;              // le 010 em octal  -> 8
    entrada3 >> hex >> c;              // le 0x10 em hex   -> 16

    cout << "Lido '10' como decimal:" << endl;
    mostrarNasTresBases(a);
    cout << endl;

    cout << "Lido '010' como octal:" << endl;
    mostrarNasTresBases(b);
    cout << endl;

    cout << "Lido '0x10' como hexadecimal:" << endl;
    mostrarNasTresBases(c);
    cout << endl;

    return 0;
}
