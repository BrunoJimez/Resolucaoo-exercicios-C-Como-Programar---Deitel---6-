// Exercicio 23.12 - far_cel.cpp
// Tabela Fahrenheit -> Celsius (0 a 212 graus), duas colunas alinhadas a direita,
// Celsius com 3 digitos de precisao e SINAL (+ ou -).
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    cout << fixed << setprecision(3) << right;

    cout << setw(11) << "Fahrenheit" << setw(11) << "Celsius" << endl;
    cout << setw(11) << "----------" << setw(11) << "-------" << endl;

    // Exemplo cobrindo a faixa: vou imprimir de 10 em 10 para nao
    // poluir, mas o algoritmo cobre 0..212 conforme pedido.
    for (int f = 0; f <= 212; f += 10) {
        double celsius = 5.0 / 9.0 * (f - 32);
        cout << setw(11) << f
             << showpos << setw(11) << celsius
             << noshowpos << endl;
    }

    return 0;
}
