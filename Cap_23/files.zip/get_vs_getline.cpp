// Exercicio 23.18 - get_vs_getline.cpp
// Mostra que:
//   - get() e getline() ambos terminam o array com '\0'
//   - get() DEIXA o delimitador no stream
//   - getline() EXTRAI e DESCARTA o delimitador
#include <iostream>
#include <sstream>
#include <iomanip>
using namespace std;

void mostrarBuffer(const char *desc, const char *buf, int max) {
    cout << desc << ": |";
    for (int i = 0; i < max; ++i) {
        if (buf[i] == '\0') { cout << "\\0"; break; }
        cout << buf[i];
    }
    cout << "|" << endl;
}

int main() {
    cout << "=== Demonstracao: get() vs getline() ===" << endl;
    cout << "Entrada (stringstream): \"abc\\ndef\"  (delimitador padrao = '\\n')"
         << endl;
    cout << endl;

    // === Teste 1: cin.get(buffer, n) ===
    {
        cout << "--- cin.get(buf, 100) ---" << endl;
        istringstream iss("abc\ndef");
        char buf[100] = {0};
        iss.get(buf, 100);
        mostrarBuffer("Buffer apos get   ", buf, 100);
        cout << "Sufixo do buffer (forcado): buf[3] = '"
             << (buf[3] == '\0' ? '0' : buf[3])
             << "' (terminador '\\0'? "
             << (buf[3] == '\0' ? "SIM" : "NAO") << ")" << endl;

        // Ver o que sobrou no stream
        char prox;
        iss.get(prox);
        cout << "Proximo char restante no stream: ASCII " << (int)prox;
        if (prox == '\n') cout << " ('\\n' -- delimitador NAO foi extraido!)";
        cout << endl;

        // Ver o resto
        string resto;
        getline(iss, resto);
        cout << "Resto apos delimitador: \"" << resto << "\"" << endl;
    }

    cout << endl;

    // === Teste 2: cin.getline(buffer, n) ===
    {
        cout << "--- cin.getline(buf, 100) ---" << endl;
        istringstream iss("abc\ndef");
        char buf[100] = {0};
        iss.getline(buf, 100);
        mostrarBuffer("Buffer apos getln ", buf, 100);
        cout << "Sufixo do buffer (forcado): buf[3] = '"
             << (buf[3] == '\0' ? '0' : buf[3])
             << "' (terminador '\\0'? "
             << (buf[3] == '\0' ? "SIM" : "NAO") << ")" << endl;

        // Ver o que sobrou no stream
        char prox;
        if (iss.get(prox)) {
            cout << "Proximo char restante no stream: '" << prox << "'";
            cout << " (delimitador '\\n' FOI extraido e descartado!)";
            cout << endl;
        }
    }

    cout << endl;
    cout << "Resumo:" << endl;
    cout << "  - Ambos: terminam o array com '\\0'." << endl;
    cout << "  - get(buf, n)     : DEIXA o delimitador no stream." << endl;
    cout << "  - getline(buf, n) : EXTRAI o delimitador (e descarta)." << endl;
    cout << "  - Caracteres nao lidos ficam no stream para futuras leituras."
         << endl;

    return 0;
}
