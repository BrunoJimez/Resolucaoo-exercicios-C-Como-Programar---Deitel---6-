// Exercicio 23.9 - larguras_campo.cpp
// Imprime inteiro 12345 e float 1.2345 em campos de tamanhos diversos,
// inclusive menores que os valores.
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int    inteiro = 12345;
    double real    = 1.2345;

    cout << "=== Inteiro 12345 em campos de tamanhos variados ===" << endl;
    for (int w = 1; w <= 12; ++w) {
        cout << "  setw(" << setw(2) << w << "): |"
             << setw(w) << inteiro << "|" << endl;
    }

    cout << "\n=== Float 1.2345 em campos de tamanhos variados ===" << endl;
    cout << fixed << setprecision(4);
    for (int w = 1; w <= 12; ++w) {
        cout << "  setw(" << setw(2) << w << "): |"
             << setw(w) << real << "|" << endl;
    }

    cout << "\nObservacao: quando a largura especificada eh MENOR que o numero"
            "\nde caracteres necessarios, C++ IGNORA a largura e imprime o valor"
            "\npor inteiro. Em nenhum caso ha truncagem ou perda de digitos." << endl;

    return 0;
}
