// Exercicio 23.16 - main_Complex.cpp
#include <iostream>
#include <sstream>
#include "Complex.h"
using namespace std;

void testar(const string &s, const string &esperado) {
    cout << "Entrada: \"" << s << "\"  (esperado: " << esperado << ")" << endl;
    istringstream iss(s);
    Complex c;
    iss >> c;
    if (iss.fail()) {
        cout << "  RESULTADO: falha." << endl;
    } else {
        cout << "  RESULTADO: " << c << endl;
    }
    cout << endl;
}

int main() {
    cout << "=== Testes da classe Complex ===" << endl << endl;

    // Casos validos basicos
    testar("3 + 8i",   "3 + 8i");
    testar("3-8i",     "3 - 8i (sem espacos)");
    testar("-3 + 8i",  "-3 + 8i (real negativo)");
    testar("-3 - 8i",  "-3 - 8i (ambos negativos)");

    // So real
    testar("5",        "5 + 0i (so real)");
    testar("-7",       "-7 + 0i");

    // So imaginario
    testar("8i",       "0 + 8i (so imag)");
    testar("-3i",      "0 - 3i");
    testar("i",        "0 + 1i (coeficiente 1 implicito)");
    testar("-i",       "0 - 1i");

    // Combinacoes
    testar("0 + 0i",   "0 + 0i");

    // Erros
    testar("abc",      "erro: nao numerico");
    testar("",         "erro: vazio");

    return 0;
}
