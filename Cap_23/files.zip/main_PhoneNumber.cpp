// Exercicio 23.14 - main_PhoneNumber.cpp
#include <iostream>
#include <sstream>
#include "PhoneNumber.h"
using namespace std;

void testarUm(const string &entrada, const string &descricao) {
    cout << "------------------------------------------------------" << endl;
    cout << "Testando: \"" << entrada << "\" -- " << descricao << endl;
    istringstream iss(entrada);
    PhoneNumber t;
    iss >> t;
    if (iss.fail()) {
        cout << "  RESULTADO: entrada invalida (failbit ativo)." << endl;
    } else {
        cout << "  RESULTADO: " << t << endl;
    }
}

int main() {
    cout << "=== Validacao de numero de telefone ===" << endl;

    // Casos validos:
    testarUm("(21) 5555-1212", "OK: codigo 21, exchange 5 valido");
    testarUm("(91) 7777-8888", "OK: codigo 91");

    // Caso invalido (a): tamanho errado
    testarUm("(21) 555-1212", "Falha (a): falta um digito");

    // Caso invalido (b): areaCode comeca com 0
    testarUm("(01) 5555-1212", "Falha (b): areaCode comeca com 0");

    // Caso invalido (b): areaCode comeca com 1
    testarUm("(11) 5555-1212", "Falha (b): areaCode comeca com 1");

    // Caso invalido (b): exchange comeca com 0
    testarUm("(21) 0555-1212", "Falha (b): exchange comeca com 0");

    // Caso invalido (b): exchange comeca com 1
    testarUm("(21) 1555-1212", "Falha (b): exchange comeca com 1");

    // Caso invalido (c): meio do areaCode nao eh 0 nem 1
    testarUm("(95) 5555-1212", "Falha (c): meio do areaCode = 5");

    // Estrutura quebrada
    testarUm("21-5555-1212-X", "Falha: sem parenteses");

    return 0;
}
