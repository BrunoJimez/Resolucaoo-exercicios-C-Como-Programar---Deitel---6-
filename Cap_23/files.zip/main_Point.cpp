// Exercicio 23.15 - main_Point.cpp
#include <iostream>
#include <sstream>
#include "Point.h"
using namespace std;

void testar(const string &s, const string &desc) {
    cout << "------------------------------------------" << endl;
    cout << "Entrada: \"" << s << "\" -- " << desc << endl;
    istringstream iss(s);
    Point p;
    iss >> p;
    if (iss.fail()) {
        cout << "  RESULTADO: failbit ativo; aplicacao NAO imprime o ponto."
             << endl;
    } else {
        cout << "  RESULTADO: " << p << endl;
    }
}

int main() {
    cout << "=== Testes da classe Point ===" << endl;
    testar("(3, 4)",      "valido: positivo");
    testar("(-5, 7)",     "valido: x negativo");
    testar("(0, 0)",      "valido: origem");
    testar("3, 4",        "INVALIDO: sem parenteses");
    testar("(3 4)",       "INVALIDO: sem virgula");
    testar("(3.5, 4)",    "INVALIDO: x nao inteiro (le 3 e para no '.')");
    testar("(abc, 4)",    "INVALIDO: x nao numerico");

    return 0;
}
