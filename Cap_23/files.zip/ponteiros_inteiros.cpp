// Exercicio 23.8 - ponteiros_inteiros.cpp
// Imprime valores de ponteiro convertidos para diferentes tipos inteiros.
// Em arquiteturas 64-bit, ponteiros ocupam 8 bytes; int (4 bytes) trunca!
#include <iostream>
#include <iomanip>
#include <cstdint>
using namespace std;

int main() {
    int   numero = 42;
    int   *p     = &numero;       // ponteiro para int

    cout << "Valor do ponteiro p (hex default):" << endl;
    cout << "  cout << p:                       " << p << endl;
    cout << "  cout << static_cast<void*>(p):   "
         << static_cast<void*>(p) << endl;

    cout << "\n=== Conversoes para tipos inteiros ===" << endl;

    // (int) -- 32 bits. Em sistemas 64-bit, TRUNCA o valor!
    cout << "  (int)p:               "
         << reinterpret_cast<intptr_t>(p)
         << " (intptr_t, valor completo)" << endl;
    cout << "  (int)p:               "
         << static_cast<int>(reinterpret_cast<intptr_t>(p) & 0xFFFFFFFF)
         << " (truncado para 32 bits)" << endl;

    // (long)p -- normalmente 64 bits em Linux/Mac, 32 em Windows
    cout << "  (long)p:              "
         << reinterpret_cast<long>(p) << endl;
    cout << "  (long long)p:         "
         << reinterpret_cast<long long>(p) << endl;
    cout << "  (unsigned)p:          "
         << static_cast<unsigned>(reinterpret_cast<intptr_t>(p) & 0xFFFFFFFF)
         << " (truncado)" << endl;
    cout << "  (uintptr_t)p (hex):   0x" << hex
         << reinterpret_cast<uintptr_t>(p) << dec << endl;

    cout << "\n=== Tamanhos em bytes (nesta arquitetura) ===" << endl;
    cout << "  sizeof(int)       = " << sizeof(int)        << endl;
    cout << "  sizeof(long)      = " << sizeof(long)       << endl;
    cout << "  sizeof(long long) = " << sizeof(long long)  << endl;
    cout << "  sizeof(int*)      = " << sizeof(int*)       << endl;
    cout << "  sizeof(intptr_t)  = " << sizeof(intptr_t)   << endl;

    cout << "\nNota: em sistema 64-bit (sizeof(int*)==8), conversao para 'int'"
            "\n      (sizeof(int)==4) TRUNCA o endereco. O tipo correto eh"
            "\n      'intptr_t' / 'uintptr_t', garantido grande o suficiente." << endl;

    return 0;
}
