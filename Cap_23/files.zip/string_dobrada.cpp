// Exercicio 23.11 - string_dobrada.cpp
// Le uma string, determina seu tamanho e imprime em largura = 2 * tamanho.
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

int main() {
    // Para reprodutibilidade, simulamos entrada via stringstream
    // (em uso interativo, substituir por getline(cin, texto)).
    string texto;
    istringstream simulada("Funcionario");
    getline(simulada, texto);

    int n = static_cast<int>(texto.size());
    int largura = 2 * n;

    cout << "String lida:    \"" << texto << "\"" << endl;
    cout << "Tamanho:        " << n << " caracteres" << endl;
    cout << "Largura dupla:  " << largura << endl;
    cout << endl;
    cout << "Alinhada a direita (default):" << endl;
    cout << "|" << setw(largura) << texto << "|" << endl;
    cout << endl;
    cout << "Alinhada a esquerda:" << endl;
    cout << "|" << left << setw(largura) << texto << "|" << endl;

    return 0;
}
