// Exercicio 23.13 - strings_delim.cpp
// Le tres strings: suzy, "suzy", 'suzy'. Aspas e apostrofos sao
// preservados como parte da string (operator>> e' "burro" para isso).
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int main() {
    // Para reprodutibilidade, simulamos entrada
    istringstream entrada("suzy \"suzy\" 'suzy'");

    string s1, s2, s3;
    entrada >> s1 >> s2 >> s3;

    cout << "Entrada simulada: suzy \"suzy\" 'suzy'" << endl;
    cout << endl;
    cout << "Strings lidas com operator>>:" << endl;
    cout << "  s1 = |" << s1 << "|" << endl;
    cout << "  s2 = |" << s2 << "|" << endl;
    cout << "  s3 = |" << s3 << "|" << endl;
    cout << endl;
    cout << "Conclusao: aspas e apostrofos NAO sao ignorados nem" << endl;
    cout << "interpretados como delimitadores. Sao tratados como" << endl;
    cout << "caracteres comuns. O delimitador eh apenas whitespace" << endl;
    cout << "(espaco, tab, newline)." << endl;

    return 0;
}
