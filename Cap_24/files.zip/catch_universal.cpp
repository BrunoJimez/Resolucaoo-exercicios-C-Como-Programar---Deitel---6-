// Exercicio 24.29 - catch_universal.cpp
// Mostra catch(...) capturando varios tipos de excecao.
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

void lanca(int caso) {
    switch (caso) {
        case 1: throw 42;                       // int
        case 2: throw 3.14;                     // double
        case 3: throw string("ola");            // std::string
        case 4: throw 'X';                      // char
        case 5: throw runtime_error("kaboom");  // classe da stdlib
        case 6: throw "literal C-string";       // const char*
        default: break;
    }
}

int main() {
    cout << "=== catch(...) capturando tipos heterogeneos ===" << endl;
    cout << "Desvantagem: nao temos info sobre o objeto capturado." << endl;
    cout << endl;

    for (int i = 1; i <= 6; ++i) {
        cout << "Caso " << i << ": ";
        try {
            lanca(i);
        }
        catch (...) {
            cout << "[catch(...)] capturei algo de tipo desconhecido" << endl;
        }
    }

    cout << "\n=== catch(...) APOS catches especificos ===" << endl;
    cout << "Quando ha catches especificos, eles tem prioridade." << endl;
    cout << "catch(...) so' captura o que nao foi pego pelos outros.\n" << endl;

    for (int i = 1; i <= 6; ++i) {
        cout << "Caso " << i << ": ";
        try {
            lanca(i);
        }
        catch (int n) {
            cout << "[catch int] " << n << endl;
        }
        catch (double d) {
            cout << "[catch double] " << d << endl;
        }
        catch (const runtime_error &e) {
            cout << "[catch runtime_error&] " << e.what() << endl;
        }
        catch (...) {
            cout << "[catch(...)] o resto" << endl;
        }
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "catch(...): captura tudo. Util como rede de seguranca," << endl;
    cout << "mas sem informacao sobre o objeto. Use APENAS quando" << endl;
    cout << "voce realmente nao puder fazer mais nada." << endl;
    return 0;
}
