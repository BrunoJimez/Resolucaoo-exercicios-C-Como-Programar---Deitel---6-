// Exercicio 24.31 - construtor_throws.cpp
// Mostra um construtor PASSANDO informacao de falha via excecao.
// Esta eh a forma idiomatica em C++: construtores nao tem valor de
// retorno; a unica maneira de sinalizar falha eh com excecoes.
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

class ContaBancaria {
public:
    ContaBancaria(const string &titular, double saldoInicial)
        : titular(titular), saldo(saldoInicial) {
        cout << "  Tentando construir conta para '" << titular << "'..." << endl;

        if (titular.empty())
            throw invalid_argument("Titular nao pode ser vazio");
        if (saldoInicial < 0)
            throw invalid_argument(
                "Saldo inicial nao pode ser negativo: " + to_string(saldoInicial));
        if (titular.size() > 50)
            throw length_error("Nome do titular muito longo");

        cout << "  Conta construida com sucesso." << endl;
    }
    ~ContaBancaria() {
        cout << "  Destruindo conta '" << titular << "' (saldo R$ "
             << saldo << ")" << endl;
    }
    void mostrar() const {
        cout << "  -> " << titular << ": R$ " << saldo << endl;
    }
private:
    string titular;
    double saldo;
};

void tentarCriar(const string &nome, double saldo) {
    cout << "\n--- Tentando: '" << nome << "' com saldo "
         << saldo << " ---" << endl;
    try {
        ContaBancaria c(nome, saldo);
        c.mostrar();
    }
    catch (const invalid_argument &e) {
        cout << "  CAPTURADO invalid_argument: " << e.what() << endl;
    }
    catch (const length_error &e) {
        cout << "  CAPTURADO length_error: " << e.what() << endl;
    }
}

int main() {
    cout << "=== Construtores e excecoes ===" << endl;

    tentarCriar("Alice", 1000.00);                                    // OK
    tentarCriar("", 500.00);                                          // Vazio
    tentarCriar("Bob", -50.00);                                       // Saldo negativo
    tentarCriar(string(60, 'A'), 100.00);                             // Nome longo
    tentarCriar("Carol", 2500.00);                                    // OK

    cout << "\n=== Conclusao ===" << endl;
    cout << "Quando o construtor lanca, o OBJETO NAO EXISTE." << endl;
    cout << "(Sem destruidor para chamar; mas membros ja construidos" << endl;
    cout << " sao destruidos -- vide Ex. 24.28.)" << endl;
    return 0;
}
