// Exercicio 24.27 - destrutores_locais.cpp
// Mostra que TODOS os destrutores de variaveis locais (automaticas)
// construidas num bloco try sao chamados antes da excecao "subir".
//
// Isso e chamado de "stack unwinding" (desempilhamento).
#include <iostream>
#include <string>
using namespace std;

class Rastreador {
public:
    Rastreador(const string &nome) : nome(nome) {
        cout << "  [+] Construindo " << nome << endl;
    }
    ~Rastreador() {
        cout << "  [-] Destruindo " << nome << endl;
    }
private:
    string nome;
};

void funcao() {
    cout << "Entrando em funcao()" << endl;
    Rastreador a("a (em funcao)");
    {
        cout << "Entrando em bloco interno" << endl;
        Rastreador b("b (bloco interno)");
        Rastreador c("c (bloco interno)");
        cout << "Lancando excecao no bloco interno..." << endl;
        throw runtime_error("kaboom");
        // c e b sao destruidos AQUI (ordem inversa de construcao)
    }
    // a tambem sera destruido durante o unwinding
    cout << "ISTO NAO DEVE APARECER" << endl;
}

int main() {
    cout << "=== Stack unwinding: destrutores chamados ===\n" << endl;

    try {
        Rastreador externo("externo (em main, ANTES do try)");
        try {
            Rastreador interno("interno (no try)");
            funcao();
            cout << "ISTO NAO APARECE" << endl;
        }
        catch (const runtime_error &e) {
            cout << "\n[catch interno] " << e.what() << endl;
        }
        cout << "\nApos catch interno, externo ainda vive...\n";
    }
    catch (...) {
        cout << "ESTE catch externo nao eh acionado" << endl;
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "Quando throw ocorre, TODOS os objetos automaticos" << endl;
    cout << "construidos no caminho do try sao destruidos em" << endl;
    cout << "ordem INVERSA. Recursos sao liberados ordenadamente." << endl;
    return 0;
}
