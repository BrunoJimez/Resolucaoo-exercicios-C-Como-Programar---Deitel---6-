// Exercicio 24.28 - destrutores_membros.cpp
// Mostra que se uma excecao eh lancada DURANTE a construcao de um
// objeto, apenas os membros JA CONSTRUIDOS sao destruidos.
#include <iostream>
#include <string>
using namespace std;

class Membro {
public:
    Membro(const string &nome, bool falhar = false) : nome(nome) {
        cout << "  [+] Construindo membro " << nome << endl;
        if (falhar) {
            cout << "  [!] Membro " << nome
                 << " esta FALHANDO durante construcao!" << endl;
            throw runtime_error("falha na construcao de " + nome);
        }
    }
    ~Membro() {
        cout << "  [-] Destruindo membro " << nome << endl;
    }
private:
    string nome;
};

class Hospedeira {
public:
    Hospedeira(bool quarto_falha)
        : m1("m1 (OK)"),
          m2("m2 (OK)"),
          m3("m3 (OK)"),
          m4("m4 (FALHA?)", quarto_falha),
          m5("m5 (nao chegaremos aqui)") {
        // Se m4 lanca durante construcao, m5 nunca eh construido.
        // O destrutor de Hospedeira NAO eh chamado, mas os destrutores
        // dos membros JA CONSTRUIDOS (m1, m2, m3) sao.
        cout << "  Corpo do construtor de Hospedeira (nao chegamos aqui se m4 falhou)" << endl;
    }
    ~Hospedeira() {
        cout << "  Destrutor de Hospedeira" << endl;
    }
private:
    Membro m1, m2, m3, m4, m5;
};

int main() {
    cout << "=== Cenario 1: construcao bem-sucedida ===\n" << endl;
    try {
        Hospedeira h1(false);
        cout << "\nh1 construida com sucesso. Saindo do escopo...\n" << endl;
    }
    catch (const exception &e) {
        cout << "Capturado: " << e.what() << endl;
    }

    cout << "\n\n=== Cenario 2: m4 falha durante construcao ===\n" << endl;
    try {
        Hospedeira h2(true);
        cout << "ISTO NAO APARECE" << endl;
    }
    catch (const exception &e) {
        cout << "\nCapturado: " << e.what() << endl;
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "No cenario 2, vemos m1, m2, m3 destruidos (ordem inversa)," << endl;
    cout << "mas m5 NUNCA foi construido, e o destrutor de Hospedeira" << endl;
    cout << "NAO foi chamado (objeto nunca chegou a existir completamente)." << endl;
    return 0;
}
