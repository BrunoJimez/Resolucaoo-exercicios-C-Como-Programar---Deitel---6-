// Exercicio 24.25 - hierarquia_runtime_error.cpp
// Mostra que um catch da classe-BASE captura excecoes das DERIVADAS.
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

// Hierarquia de excecoes derivadas de runtime_error
class ErroBanco : public runtime_error {
public:
    ErroBanco(const string &msg) : runtime_error("ErroBanco: " + msg) {}
};

class SaldoInsuficiente : public ErroBanco {
public:
    SaldoInsuficiente(double saldo, double saque)
        : ErroBanco("saldo R$ " + to_string(saldo)
                    + " menor que saque R$ " + to_string(saque)) {}
};

class ContaBloqueada : public ErroBanco {
public:
    ContaBloqueada(int id)
        : ErroBanco("conta #" + to_string(id) + " bloqueada") {}
};

class CartaoExpirado : public ErroBanco {
public:
    CartaoExpirado(int ano)
        : ErroBanco("cartao expirado em " + to_string(ano)) {}
};

void operacao(int caso) {
    switch (caso) {
        case 1: throw SaldoInsuficiente(50.00, 200.00);
        case 2: throw ContaBloqueada(12345);
        case 3: throw CartaoExpirado(2023);
        case 4: throw runtime_error("erro generico");
        default: cout << "operacao normal" << endl;
    }
}

int main() {
    cout << "=== Captura por classe-base ===\n" << endl;

    for (int i = 1; i <= 4; ++i) {
        cout << "Caso " << i << ": ";
        try {
            operacao(i);
        }
        catch (const ErroBanco &e) {
            cout << "[capturado por ErroBanco&] " << e.what() << endl;
        }
        catch (const runtime_error &e) {
            cout << "[capturado por runtime_error&] " << e.what() << endl;
        }
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "Casos 1, 2, 3 (derivados de ErroBanco) foram pegos pelo" << endl;
    cout << "catch(ErroBanco&). Caso 4 (so' runtime_error) caiu no segundo catch." << endl;
    cout << "Polimorfismo dinamico via 'is-a' em hierarquia de excecoes." << endl;

    return 0;
}
