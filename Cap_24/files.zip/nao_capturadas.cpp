// Exercicio 24.33 - nao_capturadas.cpp
// Mostra que uma funcao com seu proprio try nao precisa capturar
// TODA excecao. Algumas podem "escapar" para handlers externos.
#include <iostream>
#include <stdexcept>
using namespace std;

void operacao(int caso) {
    try {
        if (caso == 1) {
            cout << "  [interno try] lancando runtime_error" << endl;
            throw runtime_error("runtime_error de operacao");
        }
        if (caso == 2) {
            cout << "  [interno try] lancando logic_error" << endl;
            throw logic_error("logic_error de operacao");
        }
        if (caso == 3) {
            cout << "  [interno try] lancando int" << endl;
            throw 42;
        }
    }
    catch (const runtime_error &e) {
        cout << "  [interno CATCH runtime_error] tratei aqui: " << e.what() << endl;
    }
    catch (const logic_error &e) {
        cout << "  [interno CATCH logic_error] tratei aqui: " << e.what() << endl;
    }
    // Note: NAO ha catch(...) -- o int sera deixado escapar
}

int main() {
    cout << "=== Excecoes que escapam do try interno ===\n" << endl;

    for (int i = 1; i <= 3; ++i) {
        cout << "Caso " << i << ":" << endl;
        try {
            operacao(i);
        }
        catch (int n) {
            cout << "  [externo CATCH int] Capturei o que escapou: " << n << endl;
        }
        catch (...) {
            cout << "  [externo CATCH(...)] o resto" << endl;
        }
        cout << endl;
    }

    cout << "=== Conclusao ===" << endl;
    cout << "Casos 1 e 2 sao tratados internamente pela funcao." << endl;
    cout << "Caso 3 (int) NAO tem catch interno e ESCAPA para o" << endl;
    cout << "try externo, que tem catch(int). Esta eh a propagacao" << endl;
    cout << "natural de excecoes: voce so' captura o que SABE tratar." << endl;
    return 0;
}
