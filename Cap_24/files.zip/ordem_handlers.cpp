// Exercicio 24.30 - ordem_handlers.cpp
// Mostra que a ORDEM dos catches importa.
//
// Cenario A: catch da BASE vem PRIMEIRO -> captura todas as derivadas.
//            (compilador moderno emite warning sobre o catch derivado
//             ser "inalcansavel" -- por isso suprimimos com #pragma)
// Cenario B: catch da DERIVADA vem PRIMEIRO -> captura apenas a derivada.
//            O catch da base pega o resto.
#include <iostream>
#include <stdexcept>
using namespace std;

class ErroBase : public runtime_error {
public:
    ErroBase() : runtime_error("ErroBase") {}
    ErroBase(const string &m) : runtime_error(m) {}
};

class ErroEspecifico : public ErroBase {
public:
    ErroEspecifico() : ErroBase("ErroEspecifico") {}
};

void lanca_especifico() { throw ErroEspecifico(); }

int main() {
    cout << "=== Cenario A: BASE primeiro (ordem ERRADA) ===" << endl;
    cout << "Lancando ErroEspecifico..." << endl;
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wexceptions"
    try {
        lanca_especifico();
    }
    catch (const ErroBase &e) {
        cout << "  [catch ErroBase&] " << e.what()
             << "  <- pegou primeiro!" << endl;
    }
    catch (const ErroEspecifico &e) {     // INALCANSAVEL (intencional)
        cout << "  [catch ErroEspecifico&] " << e.what()
             << "  <- nunca chegamos aqui!" << endl;
    }
#pragma GCC diagnostic pop

    cout << "\n=== Cenario B: DERIVADA primeiro (ordem CORRETA) ===" << endl;
    cout << "Lancando ErroEspecifico..." << endl;
    try {
        lanca_especifico();
    }
    catch (const ErroEspecifico &e) {
        cout << "  [catch ErroEspecifico&] " << e.what()
             << "  <- pegou primeiro!" << endl;
    }
    catch (const ErroBase &e) {
        cout << "  [catch ErroBase&] " << e.what()
             << "  <- nao chegamos aqui" << endl;
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "Cenario A: o catch da base 'rouba' a excecao especifica" << endl;
    cout << "          (perdemos a chance de tratar especificamente)." << endl;
    cout << "Cenario B: catches do mais ESPECIFICO ao mais GERAL." << endl;
    cout << "          Esta eh a ORDEM CORRETA em C++." << endl;
    return 0;
}
