// Exercicio 24.32 - rethrow.cpp
// Demonstra a "indicacao" de excecao: throw; sem argumento.
// Re-lanca a excecao corrente PRESERVANDO seu tipo original.
//
// Util quando um catch quer fazer logging/cleanup mas deixar a
// excecao subir para outro handler.
#include <iostream>
#include <stdexcept>
using namespace std;

class ErroNivelA : public runtime_error {
public:
    ErroNivelA() : runtime_error("ErroNivelA") {}
};

void funcao_interna() {
    cout << "  [interna] Lancando ErroNivelA..." << endl;
    throw ErroNivelA();
}

void funcao_intermediaria() {
    cout << " [intermediaria] try em volta da chamada interna" << endl;
    try {
        funcao_interna();
    }
    catch (const ErroNivelA &e) {
        cout << " [intermediaria CATCH] Vou fazer LOGGING e re-lancar." << endl;
        cout << " [intermediaria CATCH] Log: " << e.what() << endl;
        // Forma INCORRETA seria: throw e;
        //   (faria SLICING se 'e' fosse uma classe derivada com tipo base)
        // Forma CORRETA: throw;
        throw;   // re-indica a MESMA excecao corrente
    }
}

int main() {
    cout << "=== Rethrow com 'throw;' ===" << endl;
    cout << "Note como a excecao passa por DOIS catches mas eh o" << endl;
    cout << "mesmo objeto, preservando o tipo dinamico." << endl << endl;

    try {
        cout << "[main] try em volta de intermediaria" << endl;
        funcao_intermediaria();
    }
    catch (const ErroNivelA &e) {
        cout << "[main CATCH] Capturei (re-lancada): " << e.what() << endl;
    }

    cout << "\n=== Aviso ===" << endl;
    cout << "Se 'throw;' for usado FORA de um catch corrente," << endl;
    cout << "std::terminate eh chamado. (Resposta da autorrevisao 24.14.)" << endl;
    return 0;
}
