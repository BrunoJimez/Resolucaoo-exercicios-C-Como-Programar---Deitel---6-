// Exercicio 24.34 - stack_unwinding.cpp
// Demonstra que uma excecao lancada numa funcao profundamente
// aninhada sobe pela pilha (stack unwinding) ate' o try mais
// externo que tem um handler compativel.
#include <iostream>
#include <stdexcept>
using namespace std;

// Auxiliar para mostrar a ordem de destruicao
class Marcador {
public:
    Marcador(const string &nome) : nome(nome) {
        cout << "  [+] entrando em " << nome << endl;
    }
    ~Marcador() {
        cout << "  [-] saindo de " << nome << endl;
    }
private:
    string nome;
};

void nivel5() {
    Marcador m("nivel5");
    cout << "  >>> lancando excecao no NIVEL 5 <<<" << endl;
    throw runtime_error("erro no nivel 5");
}

void nivel4() {
    Marcador m("nivel4");
    nivel5();
}

void nivel3() {
    Marcador m("nivel3");
    nivel4();
}

void nivel2() {
    Marcador m("nivel2");
    nivel3();
}

void nivel1() {
    Marcador m("nivel1");
    nivel2();
}

int main() {
    cout << "=== Stack Unwinding (desempilhamento) profundo ===\n" << endl;
    cout << "main chama nivel1 -> nivel2 -> nivel3 -> nivel4 -> nivel5,\n";
    cout << "que lanca a excecao. NENHUM dos niveis intermediarios tem\n";
    cout << "try-catch. A excecao sobe ate' main, destruindo todos os\n";
    cout << "objetos automaticos no caminho (ordem inversa).\n" << endl;

    try {
        Marcador m("main-try");
        nivel1();
        cout << "ISTO NAO APARECE" << endl;
    }
    catch (const runtime_error &e) {
        cout << "\n[main CATCH] Finalmente capturei: " << e.what() << endl;
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "Excecoes 'pulam' por cima de funcoes intermediarias," << endl;
    cout << "preservando RAII: cada destrutor de Marcador foi chamado" << endl;
    cout << "na ordem correta (do mais interno para o mais externo)." << endl;
    return 0;
}
