// Exercicio 24.26 - throw_condicional.cpp
// O resultado de uma expressao condicional ?: e' UM SO TIPO,
// determinado em compilacao. Se um dos ramos eh double e o outro
// int, o tipo comum eh double (promocao usual).
//
// Logo: ao dar throw em (cond ? umDouble : umInt), o objeto
// disparado eh SEMPRE double, independente do ramo.
#include <iostream>
using namespace std;

void lanca(bool ramoEhInt) {
    // ramoEhInt == true  -> queremos lancar 42 (int)
    // ramoEhInt == false -> queremos lancar 3.14 (double)
    // Mas o tipo da expressao eh DOUBLE (porque int promove para double).
    throw (ramoEhInt ? 42 : 3.14);
    //                ^^^^^^^^^^^^
    // Tipo da expressao = double, mesmo no ramo int.
}

int main() {
    cout << "=== Throw de expressao condicional double/int ===" << endl;
    cout << "Tentando lancar 'int' via ?:..." << endl;
    try {
        lanca(true);    // pediu int, mas vai virar double
    }
    catch (int n) {
        cout << "  CATCH int: " << n << endl;
    }
    catch (double d) {
        cout << "  CATCH double: " << d
             << "  <- mesmo no 'ramo int', virou double!" << endl;
    }

    cout << "\nTentando lancar 'double' via ?:..." << endl;
    try {
        lanca(false);   // pediu double mesmo
    }
    catch (int n) {
        cout << "  CATCH int: " << n << endl;
    }
    catch (double d) {
        cout << "  CATCH double: " << d << endl;
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "O tipo de uma expressao condicional ?: eh resolvido em" << endl;
    cout << "tempo de COMPILACAO. Quando os dois ramos sao int e" << endl;
    cout << "double, o tipo comum eh double. Por isso o catch(int)" << endl;
    cout << "NUNCA dispara, mesmo passando true." << endl;

    return 0;
}
