// Exercicio 24.24 - throw_de_catch.cpp
// Pergunta: se um catch dispara a MESMA excecao de novo, isso causa
// recursao infinita?
//
// Resposta: NAO. O catch nao se "re-captura". A excecao re-lancada
// sobe para o try mais externo (ou termina o programa se nao houver).
#include <iostream>
#include <stdexcept>
using namespace std;

int main() {
    cout << "=== Teste 1: throw novo a partir do catch ===" << endl;
    cout << "Esperamos que a 2a excecao seja capturada pelo try externo,"
            "\nNAO pelo proprio catch que a disparou." << endl;
    cout << endl;

    try {
        try {
            cout << "[interno] Lancando excecao 'primeira'..." << endl;
            throw runtime_error("primeira");
        } catch (const runtime_error &e) {
            cout << "[interno catch] Capturei: " << e.what() << endl;
            cout << "[interno catch] Vou lancar OUTRA excecao do mesmo tipo." << endl;
            throw runtime_error("segunda");
            // Esta NAO eh re-capturada pelo mesmo catch.
        }
        cout << "ISTO NAO DEVE APARECER (passou direto)" << endl;
    } catch (const runtime_error &e) {
        cout << "[externo catch] Capturei: " << e.what() << endl;
    }

    cout << "\n=== Conclusao ===" << endl;
    cout << "Sem recursao infinita. A 2a excecao foi para o try EXTERNO." << endl;
    cout << "Se nao houvesse try externo, terminate() seria chamado." << endl;
    return 0;
}
